//------------------------------------------------------------------------------
// <copyright file="CSSqlFunction.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlString FNGetWKT_GCS2UTM(SqlString wkt)
    {
        string strResult = string.Empty;
        string strWKT = wkt.ToString();
        if (strWKT.ToLower().IndexOf("point") >= 0 && strWKT.ToLower().IndexOf("multipoint") < 0)
        {
            CoordConversion.clsGISPoint point = new CoordConversion.clsGISPoint(strWKT);
            point = point.GCS2UTM();
            strResult = point.ToString();
        }
        if (strWKT.ToLower().IndexOf("linestring") >= 0 && strWKT.ToLower().IndexOf("multilinestring") < 0)
        {
            CoordConversion.clsGISLine line = new CoordConversion.clsGISLine(strWKT);
            line = line.GCS2UTM();
            strResult = line.ToString();
        }
        if (strWKT.ToLower().IndexOf("polygon") >= 0)
        {
            CoordConversion.clsGISPolygon polygon = new CoordConversion.clsGISPolygon(strWKT);
            polygon = polygon.GCS2UTM();
            strResult = polygon.ToString();
        }
        if (strWKT.ToLower().IndexOf("multilinestring") >= 0)
        {
            CoordConversion.clsGISMultiLine ml = new CoordConversion.clsGISMultiLine(strWKT);
            ml = ml.GCS2UTM();
            strResult = ml.ToString();
        }
        return new SqlString(strResult);
    }
}
