//------------------------------------------------------------------------------
// <copyright file="CSSqlFunction.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlString FNGetWKT_Lambert2GCS(SqlString wkt, SqlDouble centralMeridian, SqlDouble parallel1, SqlDouble parallel2, SqlDouble originLatitude, SqlDouble falseEasting, SqlDouble falseNorthing)
    {
        string strResult = string.Empty;
        string strWKT = wkt.ToString();
        double cenM = centralMeridian.Value;
        double par1 = parallel1.Value;
        double par2 = parallel2.Value;
        double orL = originLatitude.Value;
        double fx = falseEasting.Value;
        double fy = falseNorthing.Value;

        if (strWKT.ToLower().IndexOf("point") >= 0 && strWKT.ToLower().IndexOf("multipoint") < 0)
        {
            CoordConversion.clsGISPoint point = new CoordConversion.clsGISPoint(strWKT);
            point = point.Lambert2GCS(cenM, par1, par2, orL, fx, fy);
            strResult = point.ToString();
        }
        if (strWKT.ToLower().IndexOf("linestring") >= 0 && strWKT.ToLower().IndexOf("multilinestring") < 0)
        {
            CoordConversion.clsGISLine line = new CoordConversion.clsGISLine(strWKT);
            line = line.Lambert2GCS(cenM, par1, par2, orL, fx, fy);
            strResult = line.ToString();
        }
        if (strWKT.ToLower().IndexOf("polygon") >= 0)
        {
            CoordConversion.clsGISPolygon polygon = new CoordConversion.clsGISPolygon(strWKT);
            polygon = polygon.Lambert2GCS(cenM, par1, par2, orL, fx, fy);
            strResult = polygon.ToString();
        }
        if (strWKT.ToLower().IndexOf("multilinestring") >= 0)
        {
            CoordConversion.clsGISMultiLine ml = new CoordConversion.clsGISMultiLine(strWKT);
            ml = ml.Lambert2GCS(cenM, par1, par2, orL, fx, fy);
            strResult = ml.ToString();
        }
        return new SqlString(strResult);
    }
}
