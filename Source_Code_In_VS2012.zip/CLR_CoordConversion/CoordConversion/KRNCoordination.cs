//------------------------------------------------------------------------------
// <copyright file="CSSqlUserDefinedType.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;


[Serializable]
[Microsoft.SqlServer.Server.SqlUserDefinedType(Format.Native)]
public struct KRNCoordination: INullable
{
    private string SourceCoordSys;
    private string DestinationCoordSys;
    private Int16 sourceZone;
    private double SourceEasting;
    private double SourceNorthing;
    private Int16 DestinationZone;
    private double DestinationEasting;
    private double DestinationNorthing;


    public override string ToString()
    {
        // Replace with your own code
        return string.Format("{0},{1},{2},{3},{4},{5},{6},{7}", this.SourceCoordSys, this.sourceZone, this.SourceEasting, this.SourceNorthing, this.DestinationCoordSys, this.DestinationZone, this.DestinationEasting, this.DestinationNorthing);
    }
    
    public bool IsNull
    {
        get
        {
            // Put your code here
            bool result = string.IsNullOrEmpty(SourceCoordSys) || string.IsNullOrEmpty(DestinationCoordSys);
            result &= SourceNorthing == 0 && SourceEasting == 0;
            result &= DestinationEasting == 0 && DestinationNorthing == 0;
            return result;
        }
    }
    
    public static KRNCoordination Null
    {
        get
        {
            KRNCoordination h = new KRNCoordination();
            h.sourceZone = 0;
            h.SourceCoordSys = "";
            h.SourceEasting = 0;
            h.SourceNorthing = 0;
            h.DestinationNorthing = 0;
            h.DestinationEasting = 0;
            h.DestinationCoordSys = "";
            h.DestinationZone = 0;
            return h;
        }
    }
    
    public static KRNCoordination Parse(SqlString s)
    {
        if (s.IsNull)
            return Null;
        //this.SourceCoordSys, this.sourceZone, this.SourceEasting, this.SourceNorthing, this.DestinationCoordSys, this.DestinationZone, this.DestinationEasting, this.DestinationNorthing);
        KRNCoordination u = new KRNCoordination();
        u._null = true;

        string str = s.ToString();
        string[] tokens = str.Split(',');
        if (tokens.Length == 8)
        {
            u.SourceCoordSys = tokens[0];
            Int16.TryParse(tokens[1], out u.sourceZone);
            double.TryParse(tokens[2], out u.SourceEasting);
            double.TryParse(tokens[3], out u.SourceNorthing);

            u.DestinationCoordSys = tokens[4];
            Int16.TryParse(tokens[5], out u.DestinationZone);
            double.TryParse(tokens[6], out u.DestinationEasting);
            double.TryParse(tokens[7], out u.DestinationNorthing);
        }
        return u;
    }
    
    //// This is a place-holder method
    //public string Method1()
    //{
    //    // Put your code here
    //    return string.Empty;
    //}
    
    //// This is a place-holder static method
    //public static SqlString Method2()
    //{
    //    // Put your code here
    //    return new SqlString("");
    //}
    
    //// This is a place-holder member field
    //public int _var1;
 
    //  Private member
    private bool _null;
}