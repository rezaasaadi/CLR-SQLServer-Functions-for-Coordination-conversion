//------------------------------------------------------------------------------
// <copyright file="CSSqlFunction.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

using System.Collections;
using System.Collections.Generic;

public partial class UserDefinedFunctions
{
    private class KRNCoordination
    {
        public SqlString SourceCoordSys;
        public SqlInt32 SourceZone;
        public SqlDouble SourceEasting;
        public SqlDouble SourceNorthing;
        public SqlString DestinationCoordSys;
        public SqlInt32 DestinationZone;
        public SqlDouble DestinationEasting;
        public SqlDouble DestinationNorthing;
        public SqlString Result;
        public KRNCoordination(SqlString sourceCoordSys, SqlInt32 sourceZone, SqlDouble sourceEsating, SqlDouble sourceNorthing, SqlString destCoordSys, SqlInt32 destZone, SqlDouble destEsating, SqlDouble destNorthing)
        {
            SourceCoordSys = sourceCoordSys;
            SourceZone = sourceZone;
            SourceEasting = sourceEsating;
            SourceNorthing = sourceNorthing;
            DestinationCoordSys = destCoordSys;
            DestinationEasting = destEsating;
            DestinationNorthing = destNorthing;
            DestinationZone = destZone;
            Result = "Ok";
        }
    }
   
    #region Privates
    private const double k0 = 0.9996;
    private const double equatorRadius = 6378137;
    private const double polarRadius = 6356752.314;
    private const double flattening = 0.00335281066474748;// (equatorialRadius-polarRadius)/equatorialRadius;
    private const double inverseFlattening = 298.257223563;// 1/flattening;
    private const double rm = 6367435.679593396411;//Math.Pow(equatorRadius * polarRadius, 1 / 2.0);
    private const double e = 0.081819191311;//Math.Sqrt(1 - Math.Pow(polarRadius / equatorRadius, 2));
    private const double e1sq = 0.00673949682;//e * e / (1 - e * e);
    private const double n = (equatorRadius - polarRadius) / (equatorRadius + polarRadius);
    double arc = 0.0;
    double mu = 0.0;
    double ei = 0.0;
    double ca = 0.0;
    double cb = 0.0;
    double cc = 0.0;
    double cd = 0.0;
    double n0 = 0.0;
    double r0 = 0.0;
    double _a1 = 0.0;
    double dd0 = 0.0;
    double t0 = 0.0;
    double Q0 = 0.0;
    double lof1 = 0.0;
    double lof2 = 0.0;
    double lof3 = 0.0;
    double _a2 = 0.0;
    double phi1 = 0.0;
    double fact1 = 0.0;
    double fact2 = 0.0;
    double fact3 = 0.0;
    double fact4 = 0.0;
    double zoneCM = 0.0;
    double _a3 = 0.0;
    #endregion

    [SqlFunction(DataAccess = DataAccessKind.Read, FillRowMethodName = "FNCGS2UTM_FillRow", TableDefinition = "SourceCoordSys nvarchar(max), SourceZone int, SourceEasting float, SourceNorthing float,DestinationCoordSys nvarchar(max), DestinationZone int, DestinationEasting float, DestinationNorthing float, Result nvarchar(max)")]
    public static IEnumerable FNGCS2UTM(SqlDouble latitude, SqlDouble longitude)
    {
        KRNCoordination r = new KRNCoordination("GCS", 0, longitude, latitude, "UTM_WGS1984", 0, 0, 0);
        r.Result = "Ok";
        try
        {
            double lat = (double)latitude * Math.PI / 180;
            double rho = (equatorRadius * (1 - e * e)) / Math.Pow((1 - Math.Pow((e * Math.Sin(lat)), 2)), 1.5F);
            double nu = equatorRadius / (Math.Sqrt((1 - Math.Pow((e * Math.Sin(lat)), 2))));
            double E0 = (315 * equatorRadius * Math.Pow(n, 4) / 51) * (1 - n);
            double D0 = (35 * equatorRadius * Math.Pow(n, 3) / 48) * (1 - n + 11 * n * n / 16);
            double C0 = (15 * equatorRadius * n * n / 16) * (1 - n + (3 * n * n / 4) * (1 - n));
            double B0 = (3 * equatorRadius * n / 2) * (1 - n - (7 * n * n / 8) * (1 - n) + 55 * Math.Pow(n, 4) / 64);
            double A0 = equatorRadius * (1 - n + (5 * n * n / 4) * (1 - n) + (81 * Math.Pow(n, 4) / 64) * (1 - n));
            double S = A0 * lat - B0 * Math.Sin(2 * lat) + C0 * Math.Sin(4 * lat) - D0 * Math.Sin(6 * lat) + E0 * Math.Sin(8 * lat);
            int zone = 0;
            if (longitude < 0)
            {
                zone = (int)((180 + longitude) / 6);
                zone++;
            }
            else
            {
                zone = (int)(longitude / 6);
                zone += 31;
            }
            double p = ((double)longitude - (6 * zone - 183)) * Math.PI / 180;
            double K1 = S * k0;
            double K2 = nu * Math.Sin(lat) * Math.Cos(lat) * k0 / 2;
            double K3 = ((nu * Math.Sin(lat) * Math.Pow(Math.Cos(lat), 3)) / 24) * (5 - Math.Pow(Math.Tan(lat), 2) + 9 * e1sq * Math.Pow(Math.Cos(lat), 2) + 4 * Math.Pow(e1sq, 2) * Math.Pow(Math.Cos(lat), 4)) * k0;
            double K4 = nu * Math.Cos(lat) * k0;
            double K5 = Math.Pow(Math.Cos(lat), 3) * (nu / 6) * (1 - Math.Pow(Math.Tan(lat), 2) + e1sq * Math.Pow(Math.Cos(lat), 2)) * k0;
            double northing = (K1 + K2 * p * p + K3 * Math.Pow(p, 4));
            double easting = 500000 + (K4 * p + K5 * Math.Pow(p, 3));
            r.DestinationEasting = easting;
            r.DestinationNorthing = northing;
            r.DestinationZone = (Int16)zone;
        }
        catch (Exception exp)
        {
            r.Result = exp.ToString();
        }

        ArrayList result = new ArrayList();
        result.Add(r);

        return result;
    }

    [SqlFunction(DataAccess = DataAccessKind.Read, FillRowMethodName = "FNCGS2UTM_FillRow", TableDefinition = "SourceCoordSys nvarchar(max), SourceZone int, SourceEasting float, SourceNorthing float,DestinationCoordSys nvarchar(max), DestinationZone int, DestinationEasting float, DestinationNorthing float, Result nvarchar(max)")]
    public static IEnumerable FNGCS2Lambert(SqlDouble latitude, SqlDouble longitude, SqlDouble centralMeridian, SqlDouble parallel1, SqlDouble parallel2, SqlDouble originLatitude)
    {
        KRNCoordination r = new KRNCoordination("GCS", 0, longitude, latitude, "Lambert", 0, 0, 0);
        r.Result = "Ok";
        try
        {
            double a = equatorRadius;//6378206.4;
            double landa = (double)longitude * Math.PI / 180.0;
            double phi = (double)latitude * Math.PI / 180.0;
            double landa_0 = (double)centralMeridian * Math.PI / 180.0;
            double phi_0 = (double)originLatitude * Math.PI / 180.0;
            double phi_1 = (double)parallel1 * Math.PI / 180.0;
            double phi_2 = (double)parallel2 * Math.PI / 180.0;
            double e = Math.Sqrt(2 * flattening - Math.Pow(flattening, 2));
            double e2 = Math.Pow(e, 2);

            double t0 = Math.Tan(Math.PI / 4.0 - phi_0 / 2.0) / Math.Pow((1.0 - e * Math.Sin(phi_0)) / (1.0 + e * Math.Sin(phi_0)), e / 2.0);
            double t1 = Math.Tan(Math.PI / 4.0 - phi_1 / 2.0) / Math.Pow((1.0 - e * Math.Sin(phi_1)) / (1.0 + e * Math.Sin(phi_1)), e / 2.0);
            double t2 = Math.Tan(Math.PI / 4.0 - phi_2 / 2.0) / Math.Pow((1.0 - e * Math.Sin(phi_2)) / (1.0 + e * Math.Sin(phi_2)), e / 2.0);
            double t = Math.Tan(Math.PI / 4.0 - phi / 2.0) / Math.Pow((1.0 - e * Math.Sin(phi)) / (1.0 + e * Math.Sin(phi)), e / 2.0);
            double m1 = Math.Cos(phi_1) / Math.Pow((1.0 - e2 * Math.Pow(Math.Sin(phi_1), 2.0)), 0.5);
            double m2 = Math.Cos(phi_2) / Math.Pow((1.0 - e2 * Math.Pow(Math.Sin(phi_2), 2.0)), 0.5);
            double m = Math.Cos(phi) / Math.Pow((1.0 - e2 * Math.Pow(Math.Sin(phi), 2.0)), 0.5);

            double n = (Math.Log(m1) - Math.Log(m2)) / (Math.Log(t1) - Math.Log(t2));
            double F = m1 / (n * Math.Pow(t1, n));

            double rho = a * F * Math.Pow(t, n);
            double teta = n * (landa - landa_0);
            double rho_0 = a * F * Math.Pow(t0, n);

            r.DestinationEasting = rho * Math.Sin(teta);
            r.DestinationNorthing = rho_0 - rho * Math.Cos(teta);
            r.DestinationZone = 0;
        }
        catch (Exception exp)
        {
            r.Result = exp.ToString();
        }

        ArrayList result = new ArrayList();
        result.Add(r);

        return result;
    }

    [SqlFunction(DataAccess = DataAccessKind.Read, FillRowMethodName = "FNCGS2UTM_FillRow", TableDefinition = "SourceCoordSys nvarchar(max), SourceZone int, SourceEasting float, SourceNorthing float,DestinationCoordSys nvarchar(max), DestinationZone int, DestinationEasting float, DestinationNorthing float, Result nvarchar(max)")]
    public static IEnumerable FNLambert2GCS(SqlDouble lambertX, SqlDouble lambertY, SqlDouble centralMeridian, SqlDouble parallel1, SqlDouble parallel2, SqlDouble originLatitude, SqlDouble falseEasting, SqlDouble falseNorthing)
    {
        KRNCoordination r = new KRNCoordination("Lambert", 0, lambertX, lambertY, "GCS", 0, 0, 0);
        r.Result = "Ok";
        try
        {
            double a = 0,
            f = 0,
            phi1 = 0,
            phi2 = 0,
            phi0 = 0,
            lambda0 = 0,
            N0 = 0,
            E0 = 0,
            lamdaIn = 0,
            e = 0,
            m = 0,
            t = 0,
            m1 = 0,
            m2 = 0,
            t0 = 0,
            t1 = 0,
            t2 = 0,
            n = 0,
            Fcap = 0,
            rho = 0,
            rho0 = 0,
            gamma = 0,
            Nprime = 0,
            Eprime = 0,
            rhoprime = 0,
            tprime = 0,
            gammaprime = 0,
            phiout = 0,
            phix = 0,
            LatOut = 0,
            LongOut = 0;


            a = equatorRadius;
            f = flattening;//1 / inverseFlattening;
            phi1 = (double)parallel1 * Math.PI / 180;
            phi2 = (double)parallel2 * Math.PI / 180;
            phi0 = (double)originLatitude * Math.PI / 180;
            lambda0 = (double)centralMeridian * Math.PI / 180;
            N0 = (double)falseNorthing;
            E0 = (double)falseEasting;
            e = Math.Sqrt(2 * f - Math.Pow(f, 2));
            m1 = Math.Cos(phi1) / Math.Sqrt(1 - Math.Pow(e * Math.Sin(phi1), 2));
            m2 = Math.Cos(phi2) / Math.Sqrt(1 - Math.Pow(e * Math.Sin(phi2), 2));
            t0 = Math.Tan(Math.PI / 4 - phi0 / 2) / Math.Pow((1 - e * Math.Sin(phi0)) / (1 + e * Math.Sin(phi0)), (e / 2));
            t1 = Math.Tan(Math.PI / 4 - phi1 / 2) / Math.Pow((1 - e * Math.Sin(phi1)) / (1 + e * Math.Sin(phi1)), (e / 2));
            t2 = Math.Tan(Math.PI / 4 - phi2 / 2) / Math.Pow((1 - e * Math.Sin(phi2)) / (1 + e * Math.Sin(phi2)), (e / 2));
            n = (Math.Log(m1) - Math.Log(m2)) / (Math.Log(t1) - Math.Log(t2));
            Fcap = m1 / (n * Math.Pow(t1, n));
            rho0 = a * Fcap * Math.Pow(t0, n);
            gamma = n * (lamdaIn - lambda0);
            Nprime = (double)lambertY - N0;
            Eprime = (double)lambertX - E0;
            rhoprime = Math.Sign(n) * Math.Sqrt(Math.Pow(Eprime, 2) + Math.Pow((rho0 - Nprime), 2));
            tprime = Math.Pow((rhoprime / (a * Fcap)), (1 / n));
            gammaprime = Math.Atan(Eprime / (rho0 - Nprime));
            phiout = Math.PI / 2 - 2 * Math.Atan(tprime);

            #region to achieve convergence
            double fiIn = phiout;
            double fiOut = 0;
            int cnt = 0;
            while (cnt < 20)
            {
                fiOut = Math.PI / 2 - 2 * Math.Atan(tprime * Math.Pow(((1 - e * Math.Sin(fiIn)) / ((1 + e * Math.Sin(fiIn)))), (e / 2)));
                fiIn = fiOut;
                cnt++;
            }

            phix = fiOut;
            #endregion

            r.DestinationNorthing = phix * 180.0 / Math.PI;
            r.DestinationEasting = (gammaprime / n + lambda0) * 180.0 / Math.PI;
        }
        catch (Exception exp)
        {
            r.Result = exp.ToString();
        }

        ArrayList result = new ArrayList();
        result.Add(r);

        return result;
    }

    [SqlFunction(DataAccess = DataAccessKind.Read, FillRowMethodName = "FNCGS2UTM_FillRow", TableDefinition = "SourceCoordSys nvarchar(max), SourceZone int, SourceEasting float, SourceNorthing float,DestinationCoordSys nvarchar(max), DestinationZone int, DestinationEasting float, DestinationNorthing float, Result nvarchar(max)")]
    public static IEnumerable FNUTM2GCS(SqlInt32 utmZone, SqlDouble utmX, SqlDouble utmY)
    {
        KRNCoordination r = new KRNCoordination("UTM_WGS1984", utmZone, utmX, utmY, "GCS", 0, 0, 0);
        r.Result = "Ok";
        try
        {
            #region Set variable for utm
            double arc = (double)utmY / k0;
            double mu = arc / (equatorRadius * (1 - Math.Pow(e, 2) / 4.0 - 3 * Math.Pow(e, 4) / 64.0 - 5 * Math.Pow(e, 6) / 256.0));

            double ei = (1 - Math.Pow((1 - e * e), (1 / 2.0))) / (1 + Math.Pow((1 - e * e), (1 / 2.0)));

            double ca = 3 * ei / 2 - 27 * Math.Pow(ei, 3) / 32.0;

            double cb = 21 * Math.Pow(ei, 2) / 16 - 55 * Math.Pow(ei, 4) / 32;
            double cc = 151 * Math.Pow(ei, 3) / 96;
            double cd = 1097 * Math.Pow(ei, 4) / 512;
            double phi1 = mu + ca * Math.Sin(2 * mu) + cb * Math.Sin(4 * mu) + cc * Math.Sin(6 * mu) + cd * Math.Sin(8 * mu);

            double n0 = equatorRadius / Math.Pow((1 - Math.Pow((e * Math.Sin(phi1)), 2)), (1 / 2.0));

            double r0 = equatorRadius * (1 - e * e) / Math.Pow((1 - Math.Pow((e * Math.Sin(phi1)), 2)), (3 / 2.0));
            double fact1 = n0 * Math.Tan(phi1) / r0;

            double _a1 = 500000 - (double)utmX;
            double dd0 = _a1 / (n0 * k0);
            double fact2 = dd0 * dd0 / 2;

            double t0 = Math.Pow(Math.Tan(phi1), 2);
            double Q0 = e1sq * Math.Pow(Math.Cos(phi1), 2);
            double fact3 = (5 + 3 * t0 + 10 * Q0 - 4 * Q0 * Q0 - 9 * e1sq) * Math.Pow(dd0, 4) / 24;

            double fact4 = (61 + 90 * t0 + 298 * Q0 + 45 * t0 * t0 - 252 * e1sq - 3 * Q0 * Q0) * Math.Pow(dd0, 6) / 720;

            //
            double lof1 = _a1 / (n0 * k0);
            double lof2 = (1 + 2 * t0 + Q0) * Math.Pow(dd0, 3) / 6.0;
            double lof3 = (5 - 2 * Q0 + 28 * t0 - 3 * Math.Pow(Q0, 2) + 8 * e1sq + 24 * Math.Pow(t0, 2)) * Math.Pow(dd0, 5) / 120;
            double _a2 = (lof1 - lof2 + lof3) / Math.Cos(phi1);
            double _a3 = _a2 * 180 / Math.PI;
            #endregion

            r.DestinationNorthing = 180 * (phi1 - fact1 * (fact2 + fact3 + fact4)) / Math.PI;

            double zoneCM = 0;
            if (utmZone > 0)
            {
                zoneCM = 6 * (Int16)utmZone - 183.0;
            }
            else
            {
                zoneCM = 3.0;
            }

            r.DestinationEasting = zoneCM - _a3;
        }
        catch (Exception exp)
        {
            r.Result = exp.ToString();
        }

        ArrayList result = new ArrayList();
        result.Add(r);

        return result;

    }

    public static void FNCGS2UTM_FillRow(object krnCoordSys,out SqlString SourceCoordSys, out SqlInt32 SourceZone, out SqlDouble SourceEasting, out SqlDouble SourceNorthing, out SqlString DestinationCoordSys, out SqlInt32 DestinationZone, out SqlDouble DestinationEasting, out SqlDouble DestinationNorthing, out SqlString Result)
    {
        KRNCoordination k = (KRNCoordination)krnCoordSys;
        
        SourceCoordSys = k.SourceCoordSys;
        SourceEasting = k.SourceEasting;
        SourceNorthing = k.SourceNorthing;
        SourceZone = k.SourceZone;

        DestinationCoordSys = k.DestinationCoordSys;
        DestinationEasting = k.DestinationEasting;
        DestinationNorthing = k.DestinationNorthing;
        DestinationZone = k.DestinationZone;

        Result = k.Result;
    }

    
}
