//------------------------------------------------------------------------------
// <copyright file="CSSqlClassFile.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SqlServer.Types;

namespace CoordConversion
{
    public enum enmXYCoordinationRegion : byte
    {
        Unknown = 0, XYCoordinationRegion_1, XYCoordinationRegion_2, XYCoordinationRegion_3, XYCoordinationRegion_4
    }
    public enum ArcDirection
    {
        COUNTERCLOCKWISE = 1, CLOCKWISE = 2
    }
    public enum enmGISObjectType : byte
    {
        Unknown = 0, GISObjectType_Point, GISObjectType_LineString, GISObjectType_Polygon, GISObjectType_Ring, GISObjectType_MultiLineString
    }
    public class clsBaseGISShape
    {
        public clsBaseGISShape()
        {
        }

        public virtual void Transform(double baseX, double baseY, double baseZ)
        {
        }
        public virtual void Move(double deltaX, double deltaY, double deltaZ)
        {
        }
        public virtual bool ValidateGeometry()
        {
            string str = this.ToString();
            if (this.GISObjectType == enmGISObjectType.GISObjectType_Ring)
                str = "POLYGON(" + str + ")";
            System.Data.SqlTypes.SqlChars wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(str));
            SqlGeometry qGeometry = SqlGeometry.STGeomFromText(wkt, 1);
            return qGeometry.STIsValid().Value;
        }
        public virtual void MakeValid()
        {
        }
        public virtual bool Contains(clsBaseGISShape geometry)
        {
            System.Data.SqlTypes.SqlChars wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(geometry.ToString()));
            SqlGeometry qGeometry = SqlGeometry.STGeomFromText(wkt, 1);

            wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(this.ToString()));
            SqlGeometry thisGeometry = SqlGeometry.STGeomFromText(wkt, 1);

            System.Data.SqlTypes.SqlBoolean sqlResult = thisGeometry.STContains(qGeometry);
            return sqlResult.IsTrue;
        }
        public virtual bool Within(clsBaseGISShape geometry)
        {
            System.Data.SqlTypes.SqlChars wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(geometry.ToString()));
            SqlGeometry qGeometry = SqlGeometry.STGeomFromText(wkt, 1);

            wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(this.ToString()));
            SqlGeometry thisGeometry = SqlGeometry.STGeomFromText(wkt, 1);

            System.Data.SqlTypes.SqlBoolean sqlResult = thisGeometry.STWithin(qGeometry);
            return sqlResult.IsTrue;
        }
        public virtual bool Intersects(clsBaseGISShape geometry)
        {
            System.Data.SqlTypes.SqlChars wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(geometry.ToString()));
            SqlGeometry qGeometry = SqlGeometry.STGeomFromText(wkt, 1);

            wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(this.ToString()));
            SqlGeometry thisGeometry = SqlGeometry.STGeomFromText(wkt, 1);

            System.Data.SqlTypes.SqlBoolean sqlResult = thisGeometry.STIntersects(qGeometry);
            return sqlResult.IsTrue;
        }
        public virtual bool IsNull
        {
            get
            {
                return true;
            }
        }
        //[Browsable(false)]
        public virtual enmGISObjectType GISObjectType
        {
            get
            {
                return enmGISObjectType.Unknown;
            }
        }
        //[Browsable(false)]
        public virtual double MinX
        {
            get
            {
                return double.NaN;
            }
        }
        //[Browsable(false)]
        public virtual double MaxX
        {
            get
            {
                return double.NaN;
            }
        }
        //[Browsable(false)]
        public virtual double MaxY
        {
            get
            {
                return double.NaN;
            }
        }
        //[Browsable(false)]
        public virtual double MinY
        {
            get
            {
                return double.NaN;
            }
        }
    }

    public class clsGISPoint : clsBaseGISShape
    {
        #region Privates
        private const double k0 = 0.9996;
        private const double equatorRadius = 6378137;
        private const double polarRadius = 6356752.314;
        private const double flattening = 0.00335281066474748;// (equatorialRadius-polarRadius)/equatorialRadius;
        private const double inverseFlattening = 298.257223563;// 1/flattening;
        private const double rm = 6367435.679593396411;//Math.Pow(equatorRadius * polarRadius, 1 / 2.0);
        private const double e = 0.081819191311;//Math.Sqrt(1 - Math.Pow(polarRadius / equatorRadius, 2));
        private const double e1sq = 0.00673949682;//e * e / (1 - e * e);
        private const double n = (equatorRadius - polarRadius) / (equatorRadius + polarRadius);
        double arc = 0.0;
        double mu = 0.0;
        double ei = 0.0;
        double ca = 0.0;
        double cb = 0.0;
        double cc = 0.0;
        double cd = 0.0;
        double n0 = 0.0;
        double r0 = 0.0;
        double _a1 = 0.0;
        double dd0 = 0.0;
        double t0 = 0.0;
        double Q0 = 0.0;
        double lof1 = 0.0;
        double lof2 = 0.0;
        double lof3 = 0.0;
        double _a2 = 0.0;
        double phi1 = 0.0;
        double fact1 = 0.0;
        double fact2 = 0.0;
        double fact3 = 0.0;
        double fact4 = 0.0;
        double zoneCM = 0.0;
        double _a3 = 0.0;
        #endregion

        #region Private Properties
        private double m_X = 0.0;
        private double m_Y = 0.0;
        private double m_Z = 0.0;
        #endregion

        #region Constructors
        public clsGISPoint(double x, double y, double z)
        {
            this.m_X = x;
            this.m_Y = y;
            this.m_Z = z;
        }
        public clsGISPoint(double x, double y)
        {
            this.m_X = x;
            this.m_Y = y;
        }
        public clsGISPoint(string wellKnownText)
        {
            string str = wellKnownText.ToUpper();
            str = str.Replace("POINT", "").Trim();
            str = str.Replace("(", "").Trim();
            str = str.Replace(")", "").Trim();
            string[] strCoords = str.Split(' ');
            if (strCoords.Length != 2)
                return;
            this.m_X = double.Parse(strCoords[0], System.Globalization.CultureInfo.InvariantCulture);
            this.m_Y = double.Parse(strCoords[1], System.Globalization.CultureInfo.InvariantCulture);
        }
        #endregion

        #region Methods
        public static clsGISPoint NullPoint()
        {
            return new clsGISPoint(0, 0);
        }

        public clsGISPoint Clone()
        {
            clsGISPoint p = new clsGISPoint(this.m_X, this.m_Y, this.m_Z);
            return p;
        }

        public override bool IsNull
        {
            get
            {
                return this.m_X == 0 && this.m_Y == 0;
            }
        }
        public override string ToString()
        {
            return "POINT(" + this.m_X.ToString() + " " + this.m_Y.ToString() + ")";
        }

        public override int GetHashCode()
        {
            return this.m_X.GetHashCode() + this.m_Y.GetHashCode() + this.m_Z.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            if (!(obj is clsGISPoint))
                return false;
            clsGISPoint p = obj as clsGISPoint;
            double deltaX = Math.Abs(this.m_X - p.m_X);
            double deltaY = Math.Abs(this.m_Y - p.m_Y);
            double distance = Math.Sqrt(deltaX * deltaX + deltaY * deltaY);
            double xyResultion = 1.0 / 2260.0;
            return deltaX <= xyResultion && deltaY <= xyResultion && distance <= xyResultion;
        }

        public double GetDistance(clsGISPoint otherPoint)
        {
            return System.Math.Sqrt(System.Math.Pow(this.m_X - otherPoint.m_X, 2) + System.Math.Pow(this.m_Y - otherPoint.m_Y, 2));
        }

        public bool CanBeSnapped(clsGISPoint otherPoint, double distance)
        {
            double deltaX = System.Math.Abs(this.m_X - otherPoint.m_X);
            double deltaY = System.Math.Abs(this.m_Y - otherPoint.m_Y);
            return deltaX <= distance && deltaY <= distance;
        }

        public override void Transform(double baseX, double baseY, double baseZ)
        {
            this.m_X -= baseX;
            this.m_Y -= baseY;
            this.m_Z -= baseZ;
        }

        public override void Move(double deltaX, double deltaY, double deltaZ)
        {
            this.m_X += deltaX;
            this.m_Y += deltaY;
            this.m_Z += deltaZ;
        }
        public override void MakeValid()
        {
            System.Data.SqlTypes.SqlChars wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(this.ToString()));
            SqlGeometry qGeometry = SqlGeometry.STGeomFromText(wkt, 1);
            SqlGeometry validG = qGeometry.MakeValid();
            string strWKT = new string(validG.STAsText().Value);
            clsGISPoint p = new clsGISPoint(strWKT);
            this.X = p.X;
            this.Y = p.Y;
            this.Z = p.Z;
        }
        #endregion

        #region Public Properties
        public double X
        {
            get
            {
                return this.m_X;
            }
            set
            {
                this.m_X = value;
            }
        }
        //[clsParsGISCategory("Category_GIS")]
        //[clsParsGISDisplayName("GIS_Y_DisplayName")]
        //[clsParsGISDescription("GIS_Y_Description")]

        public double Y
        {
            get
            {
                return this.m_Y;
            }
            set
            {
                this.m_Y = value;
            }
        }
        //[Browsable(false)]
        public double Z
        {
            get
            {
                return this.m_Z;
            }
            set
            {
                this.m_Z = value;
            }
        }

        public override enmGISObjectType GISObjectType
        {
            get
            {
                return enmGISObjectType.GISObjectType_Point;
            }
        }

        //[Browsable(false)]
        public override double MinY
        {
            get
            {
                return this.m_Y;
            }
        }
        //[Browsable(false)]
        public override double MinX
        {
            get
            {
                return this.m_X;
            }
        }
        //[Browsable(false)]
        public override double MaxX
        {
            get
            {
                return this.m_X;
            }
        }
        //[Browsable(false)]
        public override double MaxY
        {
            get
            {
                return this.m_Y;
            }
        }
        #endregion

        public clsGISPoint GCS2UTM()
        {
            clsGISPoint result = new clsGISPoint(0, 0);
            double lat = (double)this.m_Y * Math.PI / 180;
            double rho = (equatorRadius * (1 - e * e)) / Math.Pow((1 - Math.Pow((e * Math.Sin(lat)), 2)), 1.5F);
            double nu = equatorRadius / (Math.Sqrt((1 - Math.Pow((e * Math.Sin(lat)), 2))));
            double E0 = (315 * equatorRadius * Math.Pow(n, 4) / 51) * (1 - n);
            double D0 = (35 * equatorRadius * Math.Pow(n, 3) / 48) * (1 - n + 11 * n * n / 16);
            double C0 = (15 * equatorRadius * n * n / 16) * (1 - n + (3 * n * n / 4) * (1 - n));
            double B0 = (3 * equatorRadius * n / 2) * (1 - n - (7 * n * n / 8) * (1 - n) + 55 * Math.Pow(n, 4) / 64);
            double A0 = equatorRadius * (1 - n + (5 * n * n / 4) * (1 - n) + (81 * Math.Pow(n, 4) / 64) * (1 - n));
            double S = A0 * lat - B0 * Math.Sin(2 * lat) + C0 * Math.Sin(4 * lat) - D0 * Math.Sin(6 * lat) + E0 * Math.Sin(8 * lat);
            int zone = 0;
            if (this.m_X < 0)
            {
                zone = (int)((180 + this.m_X) / 6);
                zone++;
            }
            else
            {
                zone = (int)(this.m_X / 6);
                zone += 31;
            }
            double p = ((double)this.m_X - (6 * zone - 183)) * Math.PI / 180;
            double K1 = S * k0;
            double K2 = nu * Math.Sin(lat) * Math.Cos(lat) * k0 / 2;
            double K3 = ((nu * Math.Sin(lat) * Math.Pow(Math.Cos(lat), 3)) / 24) * (5 - Math.Pow(Math.Tan(lat), 2) + 9 * e1sq * Math.Pow(Math.Cos(lat), 2) + 4 * Math.Pow(e1sq, 2) * Math.Pow(Math.Cos(lat), 4)) * k0;
            double K4 = nu * Math.Cos(lat) * k0;
            double K5 = Math.Pow(Math.Cos(lat), 3) * (nu / 6) * (1 - Math.Pow(Math.Tan(lat), 2) + e1sq * Math.Pow(Math.Cos(lat), 2)) * k0;
            double northing = (K1 + K2 * p * p + K3 * Math.Pow(p, 4));
            double easting = 500000 + (K4 * p + K5 * Math.Pow(p, 3));
            result.X = easting;
            result.Y = northing;
            result.Z = zone;
            return result;
        }

        public clsGISPoint UTM2GCS(Int16 zone)
        {
            clsGISPoint result = new clsGISPoint(0, 0);
            #region Set variable for utm
            double arc = this.m_Y / k0;
            double mu = arc / (equatorRadius * (1 - Math.Pow(e, 2) / 4.0 - 3 * Math.Pow(e, 4) / 64.0 - 5 * Math.Pow(e, 6) / 256.0));

            double ei = (1 - Math.Pow((1 - e * e), (1 / 2.0))) / (1 + Math.Pow((1 - e * e), (1 / 2.0)));

            double ca = 3 * ei / 2 - 27 * Math.Pow(ei, 3) / 32.0;

            double cb = 21 * Math.Pow(ei, 2) / 16 - 55 * Math.Pow(ei, 4) / 32;
            double cc = 151 * Math.Pow(ei, 3) / 96;
            double cd = 1097 * Math.Pow(ei, 4) / 512;
            double phi1 = mu + ca * Math.Sin(2 * mu) + cb * Math.Sin(4 * mu) + cc * Math.Sin(6 * mu) + cd * Math.Sin(8 * mu);

            double n0 = equatorRadius / Math.Pow((1 - Math.Pow((e * Math.Sin(phi1)), 2)), (1 / 2.0));

            double r0 = equatorRadius * (1 - e * e) / Math.Pow((1 - Math.Pow((e * Math.Sin(phi1)), 2)), (3 / 2.0));
            double fact1 = n0 * Math.Tan(phi1) / r0;

            double _a1 = 500000 - this.m_X;
            double dd0 = _a1 / (n0 * k0);
            double fact2 = dd0 * dd0 / 2;

            double t0 = Math.Pow(Math.Tan(phi1), 2);
            double Q0 = e1sq * Math.Pow(Math.Cos(phi1), 2);
            double fact3 = (5 + 3 * t0 + 10 * Q0 - 4 * Q0 * Q0 - 9 * e1sq) * Math.Pow(dd0, 4) / 24;

            double fact4 = (61 + 90 * t0 + 298 * Q0 + 45 * t0 * t0 - 252 * e1sq - 3 * Q0 * Q0) * Math.Pow(dd0, 6) / 720;

            //
            double lof1 = _a1 / (n0 * k0);
            double lof2 = (1 + 2 * t0 + Q0) * Math.Pow(dd0, 3) / 6.0;
            double lof3 = (5 - 2 * Q0 + 28 * t0 - 3 * Math.Pow(Q0, 2) + 8 * e1sq + 24 * Math.Pow(t0, 2)) * Math.Pow(dd0, 5) / 120;
            double _a2 = (lof1 - lof2 + lof3) / Math.Cos(phi1);
            double _a3 = _a2 * 180 / Math.PI;
            #endregion

            result.m_Y = 180 * (phi1 - fact1 * (fact2 + fact3 + fact4)) / Math.PI;

            double zoneCM = 0;
            if (zone > 0)
            {
                zoneCM = 6 * (Int16)zone - 183.0;
            }
            else
            {
                zoneCM = 3.0;
            }

            result.m_X = zoneCM - _a3;
            return result;
        }

        public clsGISPoint GCS2Lambert(double centralMeridian, double parallel1, double parallel2, double originLatitude)
        {
            clsGISPoint result = new clsGISPoint(0, 0);
            double a = equatorRadius;//6378206.4;
            double landa = this.m_X * Math.PI / 180.0;
            double phi = this.m_Y * Math.PI / 180.0;
            double landa_0 = (double)centralMeridian * Math.PI / 180.0;
            double phi_0 = (double)originLatitude * Math.PI / 180.0;
            double phi_1 = (double)parallel1 * Math.PI / 180.0;
            double phi_2 = (double)parallel2 * Math.PI / 180.0;
            double e = Math.Sqrt(2 * flattening - Math.Pow(flattening, 2));
            double e2 = Math.Pow(e, 2);

            double t0 = Math.Tan(Math.PI / 4.0 - phi_0 / 2.0) / Math.Pow((1.0 - e * Math.Sin(phi_0)) / (1.0 + e * Math.Sin(phi_0)), e / 2.0);
            double t1 = Math.Tan(Math.PI / 4.0 - phi_1 / 2.0) / Math.Pow((1.0 - e * Math.Sin(phi_1)) / (1.0 + e * Math.Sin(phi_1)), e / 2.0);
            double t2 = Math.Tan(Math.PI / 4.0 - phi_2 / 2.0) / Math.Pow((1.0 - e * Math.Sin(phi_2)) / (1.0 + e * Math.Sin(phi_2)), e / 2.0);
            double t = Math.Tan(Math.PI / 4.0 - phi / 2.0) / Math.Pow((1.0 - e * Math.Sin(phi)) / (1.0 + e * Math.Sin(phi)), e / 2.0);
            double m1 = Math.Cos(phi_1) / Math.Pow((1.0 - e2 * Math.Pow(Math.Sin(phi_1), 2.0)), 0.5);
            double m2 = Math.Cos(phi_2) / Math.Pow((1.0 - e2 * Math.Pow(Math.Sin(phi_2), 2.0)), 0.5);
            double m = Math.Cos(phi) / Math.Pow((1.0 - e2 * Math.Pow(Math.Sin(phi), 2.0)), 0.5);

            double n = (Math.Log(m1) - Math.Log(m2)) / (Math.Log(t1) - Math.Log(t2));
            double F = m1 / (n * Math.Pow(t1, n));

            double rho = a * F * Math.Pow(t, n);
            double teta = n * (landa - landa_0);
            double rho_0 = a * F * Math.Pow(t0, n);

            result.m_X = rho * Math.Sin(teta);
            result.m_Y = rho_0 - rho * Math.Cos(teta);
            return result;
        }

        public clsGISPoint Lambert2GCS(double centralMeridian, double parallel1, double parallel2, double originLatitude, double falseEasting, double falseNorthing)
        {
            clsGISPoint result = new clsGISPoint(0, 0);
            double a = 0,
            f = 0,
            phi1 = 0,
            phi2 = 0,
            phi0 = 0,
            lambda0 = 0,
            N0 = 0,
            E0 = 0,
            lamdaIn = 0,
            e = 0,
            m = 0,
            t = 0,
            m1 = 0,
            m2 = 0,
            t0 = 0,
            t1 = 0,
            t2 = 0,
            n = 0,
            Fcap = 0,
            rho = 0,
            rho0 = 0,
            gamma = 0,
            Nprime = 0,
            Eprime = 0,
            rhoprime = 0,
            tprime = 0,
            gammaprime = 0,
            phiout = 0,
            phix = 0,
            LatOut = 0,
            LongOut = 0;


            a = equatorRadius;
            f = flattening;//1 / inverseFlattening;
            phi1 = (double)parallel1 * Math.PI / 180;
            phi2 = (double)parallel2 * Math.PI / 180;
            phi0 = (double)originLatitude * Math.PI / 180;
            lambda0 = (double)centralMeridian * Math.PI / 180;
            N0 = (double)falseNorthing;
            E0 = (double)falseEasting;
            e = Math.Sqrt(2 * f - Math.Pow(f, 2));
            m1 = Math.Cos(phi1) / Math.Sqrt(1 - Math.Pow(e * Math.Sin(phi1), 2));
            m2 = Math.Cos(phi2) / Math.Sqrt(1 - Math.Pow(e * Math.Sin(phi2), 2));
            t0 = Math.Tan(Math.PI / 4 - phi0 / 2) / Math.Pow((1 - e * Math.Sin(phi0)) / (1 + e * Math.Sin(phi0)), (e / 2));
            t1 = Math.Tan(Math.PI / 4 - phi1 / 2) / Math.Pow((1 - e * Math.Sin(phi1)) / (1 + e * Math.Sin(phi1)), (e / 2));
            t2 = Math.Tan(Math.PI / 4 - phi2 / 2) / Math.Pow((1 - e * Math.Sin(phi2)) / (1 + e * Math.Sin(phi2)), (e / 2));
            n = (Math.Log(m1) - Math.Log(m2)) / (Math.Log(t1) - Math.Log(t2));
            Fcap = m1 / (n * Math.Pow(t1, n));
            rho0 = a * Fcap * Math.Pow(t0, n);
            gamma = n * (lamdaIn - lambda0);
            Nprime = this.m_Y - N0;
            Eprime = this.m_X - E0;
            rhoprime = Math.Sign(n) * Math.Sqrt(Math.Pow(Eprime, 2) + Math.Pow((rho0 - Nprime), 2));
            tprime = Math.Pow((rhoprime / (a * Fcap)), (1 / n));
            gammaprime = Math.Atan(Eprime / (rho0 - Nprime));
            phiout = Math.PI / 2 - 2 * Math.Atan(tprime);

            #region to achieve convergence
            double fiIn = phiout;
            double fiOut = 0;
            int cnt = 0;
            while (cnt < 20)
            {
                fiOut = Math.PI / 2 - 2 * Math.Atan(tprime * Math.Pow(((1 - e * Math.Sin(fiIn)) / ((1 + e * Math.Sin(fiIn)))), (e / 2)));
                fiIn = fiOut;
                cnt++;
            }

            phix = fiOut;
            #endregion

            result.m_Y = phix * 180.0 / Math.PI;
            result.m_X = (gammaprime / n + lambda0) * 180.0 / Math.PI;
            return result;
        }
    }

    public class clsGISLine : clsBaseGISShape
    {
        #region Private Properties
        private List<clsGISPoint> m_Points;
        private float m_Length = 0.0F;
        #endregion

        #region Constructors
        public clsGISLine(clsGISPoint fromPoint, clsGISPoint toPoint)
        {
            this.m_Points = new List<clsGISPoint>();
            this.m_Points.Add(fromPoint.Clone());
            this.m_Points.Add(toPoint.Clone());
            this.CalculateLength();
        }
        public clsGISLine(List<clsGISPoint> points)
        {
            this.m_Points = points;
            this.CalculateLength();
        }
        public clsGISLine(double[] Xs, double[] Ys)
        {
            this.m_Points = new List<clsGISPoint>();
            if (Xs.Length != Ys.Length || Xs.Length == 0 || Ys.Length == 0)
                return;
            this.m_Points = new List<clsGISPoint>();
            for (int i = 0; i < Xs.Length; i++)
            {
                clsGISPoint p = new clsGISPoint(Xs[i], Ys[i]);
                this.m_Points.Add(p);
            }
            this.CalculateLength();
        }
        public clsGISLine(string wellKnownText)
        {
            if (wellKnownText.Trim().Length == 0)
            {
                this.m_Points = clsGISLine.NullLine().Points;
                this.m_Length = 0;
                return;
            }
            this.m_Points = new List<clsGISPoint>();
            string str = wellKnownText.ToUpper();
            str = str.Replace("LINESTRING", "").Trim();
            str = str.Replace("(", "").Trim();
            str = str.Replace(")", "").Trim();
            string[] strPoints = str.Split(',');
            for (int i = 0; i < strPoints.Length; i++)
            {
                clsGISPoint p = new clsGISPoint(strPoints[i]);
                this.m_Points.Add(p);
            }
            this.CalculateLength();
        }
        #endregion

        #region Methods
        public static clsGISLine NullLine()
        {
            return new clsGISLine(clsGISPoint.NullPoint(), clsGISPoint.NullPoint());
        }
        public override bool IsNull
        {
            get
            {
                bool bAllNull = true;
                foreach (clsGISPoint p in this.m_Points)
                    bAllNull &= p.IsNull;
                return bAllNull;
            }
        }
        public clsGISLine Clone()
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            for (int i = 0; i < this.m_Points.Count; i++)
                points.Add(this.m_Points[i].Clone());
            clsGISLine l = new clsGISLine(points);
            return l;
        }
        public void AddPoint(clsGISPoint point)
        {
            this.m_Points.Add(point);
            this.CalculateLength();
        }
        public void InsertPoint(int atIndex, clsGISPoint point)
        {
            this.m_Points.Insert(atIndex, point);
            this.CalculateLength();
        }
        public void RemovePoint(clsGISPoint point)
        {
            int idx = -1;
            for (int i = 0; i < this.m_Points.Count; i++)
                if (this.m_Points[i].Equals(point))
                {
                    idx = i;
                    break;
                }
            if (idx >= 0 && this.m_Points.Count > 2)
            {
                this.m_Points.RemoveAt(idx);
                this.CalculateLength();
            }
        }
        public void RemovePointAt(int pointIndex)
        {
            if (pointIndex >= 0 && pointIndex < this.m_Points.Count && this.m_Points.Count > 2)
                this.m_Points.RemoveAt(pointIndex);
            this.CalculateLength();
        }
        private void CalculateLength()
        {
            this.m_Length = 0.0F;
            for (int i = 0; i < this.m_Points.Count - 1; i++)
            {
                clsGISPoint point1 = this.m_Points[i];
                clsGISPoint point2 = this.m_Points[i + 1];
                this.m_Length += (float)Math.Sqrt(Math.Pow((point1.X - point2.X), 2) + Math.Pow((point1.Y - point2.Y), 2));
            }
        }
        public override string ToString()
        {
            if (this.m_Points == null)
                return null;
            string str = "LINESTRING(";
            for (int i = 0; i < this.m_Points.Count; i++)
            {
                if (str.Length > 11)
                    str += ",";
                str += this.m_Points[i].ToString().Replace("POINT", "").Replace("(", "").Replace(")", "");
            }
            str += ")";
            return str;
        }
        public override int GetHashCode()
        {
            int hc = 0;
            if (this.m_Points != null)
            {
                foreach (clsGISPoint p in this.m_Points)
                    hc += p.GetHashCode();
            }
            return hc;
        }
        public override bool Equals(object obj)
        {
            if (!(obj is clsGISLine))
                return false;
            clsGISLine otherLine = obj as clsGISLine;
            if (otherLine.m_Points == null || this.m_Points == null)
                return false;
            if (otherLine.m_Points.Count != this.m_Points.Count)
                return false;
            for (int i = 0; i < this.m_Points.Count; i++)
                if (!this.m_Points[i].Equals(otherLine.m_Points[i]))
                    return false;
            return true;
        }
        public byte IsConnectedTo(clsGISPoint point)
        {
            if (this.FromPoint.Equals(point))
                return 1;
            else if (this.EndPoint.Equals(point))
                return (byte)this.m_Points.Count;
            return 0;
        }
        public byte IsConnectedTo(clsGISLine line)
        {
            //Result 4 bits binary number
            //bit[0]---->this line from point
            //bit[1]---->this line end point
            //bit[2]---->another line from point
            //bit[3]---->another line end point
            byte b1 = this.IsConnectedTo(line.FromPoint);
            byte b2 = this.IsConnectedTo(line.EndPoint);
            if (b1 == 1 && b2 == 0)
                return 5;
            if (b1 == this.PointCount && b2 == 0)
                return 6;
            if (b2 == 1 && b1 == 0)
                return 9;
            if (b2 == this.PointCount && b1 == 0)
                return 12;
            return 0;
        }
        public void SetPointAt(int pointIndex, clsGISPoint point)
        {
            if (pointIndex >= 0 && pointIndex < this.m_Points.Count)
            {
                this.m_Points[pointIndex].X = point.X;
                this.m_Points[pointIndex].Y = point.Y;
                this.m_Points[pointIndex].Z = point.Z;
            }
            this.CalculateLength();
        }
        public clsGISPoint GetPointAlong(int firstPointIndex, int secondPointIndex, double distance)
        {
            clsGISPoint gp1 = this.m_Points[firstPointIndex];
            clsGISPoint gp2 = this.m_Points[secondPointIndex];

            if (gp1.GetDistance(gp2) <= distance)
            {
                if (firstPointIndex < secondPointIndex)
                {
                    int pIdx = firstPointIndex + 1;
                    while (gp1.GetDistance(gp2) <= distance && pIdx < this.m_Points.Count - 1)
                    {
                        gp1 = this.m_Points[pIdx];
                        gp2 = this.m_Points[pIdx + 1];
                        pIdx++;
                    }
                }
                else
                {
                    int pIdx = firstPointIndex - 1;
                    while (gp1.GetDistance(gp2) <= distance && pIdx > 0)
                    {
                        gp1 = this.m_Points[pIdx];
                        gp2 = this.m_Points[pIdx - 1];
                        pIdx--;
                    }
                }
            }

            if (gp1.GetDistance(gp2) <= distance)
                return null;

            clsGISPoint tp = new clsGISPoint(-1.0, -1.0);
            bool isVertical = gp1.X == gp2.X;
            if (isVertical)
            {
                tp.X = gp1.X;
                if (gp2.Y > gp1.Y)
                    tp.Y = gp1.Y + distance;
                else
                    tp.Y = gp1.Y - distance;
                return tp;
            }
            double alfa = (gp2.Y - gp1.Y) / (gp2.X - gp1.X);
            tp.X = -1.0;
            tp.Y = -1.0;
            double x1 = gp1.X + distance / Math.Sqrt(Math.Pow(alfa, 2) + 1);
            double x2 = gp1.X - distance / Math.Sqrt(Math.Pow(alfa, 2) + 1);
            double y1 = gp1.Y + alfa * (x1 - gp1.X);
            double y2 = gp1.Y + alfa * (x2 - gp1.X);

            if (x1 >= System.Math.Min(gp1.X, gp2.X) && x1 <= System.Math.Max(gp1.X, gp2.X) && y1 >= System.Math.Min(gp1.Y, gp2.Y) && y1 <= System.Math.Max(gp1.Y, gp2.Y))
            {
                if (x1 == gp1.X && y1 == gp1.Y)
                {
                    tp.X = gp1.X;
                    if (gp2.Y > gp1.Y)
                        tp.Y = gp1.Y + distance;
                    else
                        tp.Y = gp1.Y - distance;
                }
                else
                {
                    tp.X = x1;
                    tp.Y = y1;
                }
            }
            else if (x2 >= System.Math.Min(gp1.X, gp2.X) && x2 <= System.Math.Max(gp1.X, gp2.X) && y2 >= System.Math.Min(gp1.Y, gp2.Y) && y2 <= System.Math.Max(gp1.Y, gp2.Y))
            {
                if (x2 == gp1.X && y2 == gp1.Y)
                {
                    tp.X = gp1.X;
                    if (gp2.Y > gp1.Y)
                        tp.Y = gp1.Y + distance;
                    else
                        tp.Y = gp1.Y - distance;
                }
                else
                {
                    tp.X = x2;
                    tp.Y = y2;
                }
            }
            return tp;
        }
        public clsGISPoint GetPointAlongFree(int firstPointIndex, int secondPointIndex, double distance)
        {
            clsGISPoint gp1 = this.m_Points[firstPointIndex];
            clsGISPoint gp2 = this.m_Points[secondPointIndex];

            clsGISPoint tp = new clsGISPoint(-1.0, -1.0);
            if (gp1.X == gp2.X)
            {
                tp.X = gp1.X;
                if (gp2.Y > gp1.Y)
                    tp.Y = gp1.Y + distance;
                else
                    tp.Y = gp1.Y - distance;
                return tp;
            }
            if (gp1.Y == gp2.Y)
            {
                tp.Y = gp1.Y;
                if (gp2.X > gp1.X)
                    tp.X = gp1.X + distance;
                else
                    tp.X = gp1.X - distance;
                return tp;
            }

            double alfa = (gp2.Y - gp1.Y) / (gp2.X - gp1.X);
            double x1 = gp1.X + distance / Math.Sqrt(Math.Pow(alfa, 2) + 1);
            double x2 = gp1.X - distance / Math.Sqrt(Math.Pow(alfa, 2) + 1);
            double y1 = gp1.Y + alfa * (x1 - gp1.X);
            double y2 = gp1.Y + alfa * (x2 - gp1.X);

            double lineDistance = gp1.GetDistance(gp2);
            if (lineDistance >= distance)
            {
                if (x1 >= System.Math.Min(gp1.X, gp2.X) && x1 <= System.Math.Max(gp1.X, gp2.X) && y1 >= System.Math.Min(gp1.Y, gp2.Y) && y1 <= System.Math.Max(gp1.Y, gp2.Y))
                {
                    if (x1 == gp1.X && y1 == gp1.Y)
                    {
                        tp.X = gp1.X;
                        if (gp2.Y > gp1.Y)
                            tp.Y = gp1.Y + distance;
                        else
                            tp.Y = gp1.Y - distance;
                    }
                    else
                    {
                        tp.X = x1;
                        tp.Y = y1;
                    }
                }
                else if (x2 >= System.Math.Min(gp1.X, gp2.X) && x2 <= System.Math.Max(gp1.X, gp2.X) && y2 >= System.Math.Min(gp1.Y, gp2.Y) && y2 <= System.Math.Max(gp1.Y, gp2.Y))
                {
                    if (x2 == gp1.X && y2 == gp1.Y)
                    {
                        tp.X = gp1.X;
                        if (gp2.Y > gp1.Y)
                            tp.Y = gp1.Y + distance;
                        else
                            tp.Y = gp1.Y - distance;
                    }
                    else
                    {
                        tp.X = x2;
                        tp.Y = y2;
                    }
                }
            }
            else
            {
                if (gp1.X < gp2.X && gp1.Y < gp2.Y)
                {
                    if (x1 > gp1.X && y1 > gp1.Y)
                    {
                        tp.X = x1;
                        tp.Y = y1;
                    }
                    else
                    {
                        tp.X = x2;
                        tp.Y = y2;
                    }
                }
                if (gp1.X > gp2.X && gp1.Y < gp2.Y)
                {
                    if (x1 < gp1.X && y1 > gp1.Y)
                    {
                        tp.X = x1;
                        tp.Y = y1;
                    }
                    else
                    {
                        tp.X = x2;
                        tp.Y = y2;
                    }
                }
                if (gp1.X > gp2.X && gp1.Y > gp2.Y)
                {
                    if (x1 < gp1.X && y1 < gp1.Y)
                    {
                        tp.X = x1;
                        tp.Y = y1;
                    }
                    else
                    {
                        tp.X = x2;
                        tp.Y = y2;
                    }
                }
                if (gp1.X < gp2.X && gp1.Y > gp2.Y)
                {
                    if (x1 > gp1.X && y1 < gp1.Y)
                    {
                        tp.X = x1;
                        tp.Y = y1;
                    }
                    else
                    {
                        tp.X = x2;
                        tp.Y = y2;
                    }
                }
            }
            return tp;
        }
        public float GetLineAngle(int firstPointIndex, int secondPointIndex)
        {
            clsGISPoint p1 = this.m_Points[firstPointIndex];
            clsGISPoint p2 = this.m_Points[secondPointIndex];

            double deltaX1 = p2.X - p1.X;
            double deltaY1 = p2.Y - p1.Y;
            if (deltaX1 == 0)
                return (float)Math.Round((deltaY1 > 0 ? Math.PI / 2 : 3 * Math.PI / 2), 3);
            float alfa = (float)Math.Atan(deltaY1 / deltaX1);
            if (deltaX1 > 0 && deltaY1 >= 0)
                return (float)Math.Round(alfa, 3);
            if (deltaX1 > 0 && deltaY1 <= 0)
                return (float)Math.Round(2 * Math.PI + alfa, 3);
            if (deltaX1 < 0 && deltaY1 <= 0)
                return (float)Math.Round(Math.PI + alfa, 3);
            return (float)Math.Round(Math.PI + alfa, 3);
        }
        public double GetLinesAngle(int firstPointIndex, int secondPointIndex, int thirdPointIndex, ref ArcDirection ArcDir)
        {
            if (this.m_Points.Count < 3)
                return -1.0;

            clsGISPoint p1 = this.m_Points[firstPointIndex];
            clsGISPoint p2 = this.m_Points[secondPointIndex];
            clsGISPoint p3 = this.m_Points[thirdPointIndex];

            double deltaX1 = p2.X - p1.X;
            double deltaY1 = p2.Y - p1.Y;
            double deltaX2 = p3.X - p2.X;
            double deltaY2 = p3.Y - p2.Y;

            double alfa, beta;
            if (deltaX1 == 0)
                alfa = Math.PI / 2;
            else
                alfa = Math.Atan(Math.Abs(deltaY1) / Math.Abs(deltaX1));
            if (deltaX2 == 0)
                beta = Math.PI / 2;
            else
                beta = Math.Atan(Math.Abs(deltaY2) / Math.Abs(deltaX2));
            //...First Line in Region 1
            if (deltaX1 >= 0 && deltaY1 >= 0 && deltaX2 >= 0 && deltaY2 >= 0)
            {
                ArcDir = alfa > beta ? ArcDirection.CLOCKWISE : ArcDirection.COUNTERCLOCKWISE;
                return Math.PI - Math.Abs(alfa - beta);
            }
            if (deltaX1 >= 0 && deltaY1 >= 0 && deltaX2 < 0 && deltaY2 >= 0)
            {
                ArcDir = ArcDirection.COUNTERCLOCKWISE;
                return alfa + beta;
            }
            if (deltaX1 >= 0 && deltaY1 >= 0 && deltaX2 < 0 && deltaY2 < 0)
            {
                ArcDir = alfa > beta ? ArcDirection.COUNTERCLOCKWISE : ArcDirection.CLOCKWISE;
                return Math.Abs(alfa - beta);
            }
            if (deltaX1 >= 0 && deltaY1 >= 0 && deltaX2 >= 0 && deltaY2 < 0)
            {
                ArcDir = ArcDirection.CLOCKWISE;
                return Math.PI - (alfa + beta);
            }
            //...First Line in region 2
            if (deltaX1 < 0 && deltaY1 >= 0 && deltaX2 < 0 && deltaY2 >= 0)
            {
                ArcDir = alfa > beta ? ArcDirection.CLOCKWISE : ArcDirection.COUNTERCLOCKWISE;
                return Math.PI - Math.Abs(alfa - beta);
            }
            if (deltaX1 < 0 && deltaY1 >= 0 && deltaX2 >= 0 && deltaY2 >= 0)
            {
                ArcDir = ArcDirection.CLOCKWISE;
                return alfa + beta;
            }
            if (deltaX1 < 0 && deltaY1 >= 0 && deltaX2 < 0 && deltaY2 < 0)
            {
                ArcDir = ArcDirection.COUNTERCLOCKWISE;
                return Math.PI - (alfa + beta);
            }
            if (deltaX1 < 0 && deltaY1 >= 0 && deltaX2 >= 0 && deltaY2 < 0)
            {
                ArcDir = alfa > beta ? ArcDirection.COUNTERCLOCKWISE : ArcDirection.CLOCKWISE;
                return Math.Abs(alfa - beta);
            }
            //...First Line in region 3
            if (deltaX1 < 0 && deltaY1 < 0 && deltaX2 < 0 && deltaY2 < 0)
            {
                ArcDir = alfa > beta ? ArcDirection.CLOCKWISE : ArcDirection.COUNTERCLOCKWISE;
                return Math.PI - Math.Abs(alfa - beta);
            }
            if (deltaX1 < 0 && deltaY1 < 0 && deltaX2 >= 0 && deltaY2 < 0)
            {
                ArcDir = ArcDirection.COUNTERCLOCKWISE;
                return alfa + beta;
            }
            if (deltaX1 < 0 && deltaY1 < 0 && deltaX2 >= 0 && deltaY2 >= 0)
            {
                ArcDir = alfa > beta ? ArcDirection.COUNTERCLOCKWISE : ArcDirection.CLOCKWISE;
                return Math.Abs(alfa - beta);
            }
            if (deltaX1 < 0 && deltaY1 < 0 && deltaX2 < 0 && deltaY2 >= 0)
            {
                ArcDir = ArcDirection.COUNTERCLOCKWISE;
                return Math.PI - (alfa + beta);
            }
            //...First line in region 4
            if (deltaX1 >= 0 && deltaY1 < 0 && deltaX2 >= 0 && deltaY2 < 0)
            {
                ArcDir = alfa > beta ? ArcDirection.CLOCKWISE : ArcDirection.COUNTERCLOCKWISE;
                return Math.PI - Math.Abs(alfa - beta);
            }
            if (deltaX1 >= 0 && deltaY1 < 0 && deltaX2 < 0 && deltaY2 < 0)
            {
                ArcDir = ArcDirection.CLOCKWISE;
                return alfa + beta;
            }
            if (deltaX1 >= 0 && deltaY1 < 0 && deltaX2 >= 0 && deltaY2 >= 0)
            {
                ArcDir = ArcDirection.COUNTERCLOCKWISE;
                return Math.PI - (alfa + beta);
            }
            if (deltaX1 >= 0 && deltaY1 < 0 && deltaX2 < 0 && deltaY2 >= 0)
            {
                ArcDir = alfa < beta ? ArcDirection.COUNTERCLOCKWISE : ArcDirection.CLOCKWISE;
                return Math.Abs(beta - alfa);
            }

            return -1;
        }
        public double GetPartLineLength(int fromPointIndex)
        {
            if (fromPointIndex < 0 || fromPointIndex > this.m_Points.Count - 1)
                return -1.0;
            clsGISPoint p1 = this.m_Points[fromPointIndex];
            clsGISPoint p2 = null;
            if (fromPointIndex == this.m_Points.Count - 1)
                p2 = this.m_Points[fromPointIndex - 1];
            else
                p2 = this.m_Points[fromPointIndex + 1];
            return p1.GetDistance(p2);
        }
        //???? ??? ???? ?? ?? ?? ??????????
        public bool IsPointOnLine(clsGISPoint point)
        {
            bool bIsOnLine = false;
            for (int i = 0; i < this.m_Points.Count - 1; i++)
            {
                clsGISPoint p1 = this.m_Points[i];
                clsGISPoint p2 = this.m_Points[i + 1];

                if (p1.X != p2.X)
                {
                    double a = (p2.Y - p1.Y) / (p2.X - p1.X);
                    double b = p2.Y - p2.X * a;
                    double y = a * point.X + b;
                    double deltaY = Math.Abs(y - point.Y);
                    bIsOnLine = deltaY <= double.Epsilon;
                }
                else
                {
                    if (point.X == p1.X)
                    {
                        if (p2.X > p1.Y)
                            bIsOnLine = point.Y >= p1.Y && point.Y <= p2.Y;
                        else if (p2.Y < p1.Y)
                            bIsOnLine = point.Y >= p2.Y && point.Y <= p1.Y;
                    }
                }
                if (bIsOnLine)
                    break;
            }
            return bIsOnLine;
        }
        public int GetVertexIndex(clsGISPoint point)
        {
            int idx = -1;
            for (int i = 0; i < this.m_Points.Count; i++)
            {
                clsGISPoint p = this.m_Points[i];
                if (p.Equals(point))
                {
                    idx = i;
                    break;
                }
            }
            return idx;
        }
        //???? ?? ?? ???? ?? ?? ?? ????? ???? ? ????? ????? ?????? ?????
        public clsGISPoint GetPointAtDistance(int vertextNo, int otherVertexNo, double distance, bool clockWise)
        {
            if (vertextNo < 0 || vertextNo >= this.PointCount)
                return null;
            if (otherVertexNo < 0 || otherVertexNo >= this.PointCount)
                return null;

            clsGISPoint p1 = this.m_Points[vertextNo];
            clsGISPoint p2 = this.m_Points[otherVertexNo];
            if (p1.X == p2.X)
            {
                if (clockWise)
                    return new clsGISPoint(p1.X + distance, p1.Y);
                else
                    return new clsGISPoint(p1.X - distance, p1.Y);
            }
            else if (p1.Y == p2.Y)
            {
                if (clockWise)
                    return new clsGISPoint(p1.X, p1.Y + distance);
                else
                    return new clsGISPoint(p1.X, p1.Y - distance);
            }
            double alfa = (p1.Y - p2.Y) / (p1.X - p2.X);
            double y = 0, x = 0;
            if (alfa < 0)
            {
                if (clockWise)
                {
                    x = p1.X + Math.Sqrt((Math.Pow(distance, 2) * Math.Pow(alfa, 2)) / (1.0 + Math.Pow(alfa, 2)));
                    y = p1.Y - ((x - p1.X) / alfa);
                }
                else
                {
                    x = p1.X - Math.Sqrt((Math.Pow(distance, 2) * Math.Pow(alfa, 2)) / (1.0 + Math.Pow(alfa, 2)));
                    y = p1.Y - ((x - p1.X) / alfa);
                }
                //if (clockWise)
                //    y = p1.Y + Math.Sqrt(Math.Pow(distance, 2) / (Math.Pow(alfa, 2) + 1));
                //else
                //    y = p1.Y - Math.Sqrt(Math.Pow(distance, 2) / (Math.Pow(alfa, 2) + 1));
                //x = p1.X - alfa * (y - p1.Y);
            }
            else
            {
                if (clockWise)
                {
                    x = p1.X + Math.Sqrt((Math.Pow(distance, 2) * Math.Pow(alfa, 2)) / (1.0 + Math.Pow(alfa, 2)));
                    y = p1.Y - ((x - p1.X) / alfa);
                }
                else
                {
                    x = p1.X - Math.Sqrt((Math.Pow(distance, 2) * Math.Pow(alfa, 2)) / (1.0 + Math.Pow(alfa, 2)));
                    y = p1.Y - ((x - p1.X) / alfa);
                }
                //if (clockWise)
                //    y = p1.Y - Math.Sqrt(Math.Pow(distance, 2) / (Math.Pow(alfa, 2) + 1));
                //else
                //    y = p1.Y + Math.Sqrt(Math.Pow(distance, 2) / (Math.Pow(alfa, 2) + 1));
                //x = p1.X - alfa * (y - p1.Y);
            }
            return new clsGISPoint(x, y);
        }
        public override void Transform(double baseX, double baseY, double baseZ)
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            foreach (clsGISPoint p in this.m_Points)
            {
                p.Transform(baseX, baseY, baseZ);
                points.Add(p.Clone());
            }
            this.m_Points.Clear();
            this.m_Points = points;
        }
        public override void Move(double deltaX, double deltaY, double deltaZ)
        {
            foreach (clsGISPoint p in this.m_Points)
                p.Move(deltaX, deltaY, deltaZ);
        }
        public override bool ValidateGeometry()
        {
            if (this.m_Points.Count <= 1)
                return false;
            double val = double.MaxValue;
            for (int i = 0; i < this.m_Points.Count; i++)
            {
                clsGISPoint p1 = this.m_Points[i];
                int j = i + 1;
                if (j >= this.m_Points.Count)
                    j = 0;
                clsGISPoint p2 = this.m_Points[j];
                double distance = p1.GetDistance(p2);
                if (distance < val)
                    val = distance;
            }
            double xyResultion = 1.0 / 2260.0;
            if (val < xyResultion)
                return false;
            return base.ValidateGeometry();
        }
        public override void MakeValid()
        {
            System.Data.SqlTypes.SqlChars wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(this.ToString()));
            SqlGeometry qGeometry = SqlGeometry.STGeomFromText(wkt, 1);
            SqlGeometry validG = qGeometry.MakeValid();
            string strWKT = new string(validG.STAsText().Value);
            clsGISLine l = new clsGISLine(strWKT);
            this.m_Points = l.Points;
            this.m_Length = l.m_Length;
        }
        public bool IsOnLine(clsGISPoint otherPoint)
        {
            clsGISPoint p1 = null, p2 = null;
            for (int i = 0; i < this.m_Points.Count - 1; i++)
            {
                if ((otherPoint.X >= this.m_Points[i].X && otherPoint.X <= this.m_Points[i + 1].X) || (otherPoint.X >= this.m_Points[i + 1].X && otherPoint.X <= this.m_Points[i].X))
                {
                    if ((otherPoint.Y >= this.m_Points[i].Y && otherPoint.Y <= this.m_Points[i + 1].Y) || (otherPoint.Y >= this.m_Points[i + 1].Y && otherPoint.Y <= this.m_Points[i].Y))
                    {
                        p1 = this.m_Points[i];
                        p2 = this.m_Points[i + 1];
                        break;
                    }
                }
            }

            if (p2 == null || p1 == null)
                return false;

            if (p1.Equals(otherPoint) || p2.Equals(otherPoint))
                return true;
            double distance1 = p1.GetDistance(p2);
            double distance2 = p1.GetDistance(otherPoint);
            double distance3 = p2.GetDistance(otherPoint);
            double delta = Math.Abs(distance1 - (distance2 + distance3));
            return delta <= (1.0 / 2260.0);
        }

        #endregion

        #region Public Properties
        //[clsParsGISCategory("Category_GIS")]
        //[clsParsGISDisplayName("GIS_LineLength_DisplayName")]
        //[clsParsGISDescription("GIS_LineLength_Description")]
        
        public float LineLength
        {
            get
            {
                return this.m_Length;
            }
        }

        //[clsParsGISCategory("Category_GIS")]
        //[clsParsGISDisplayName("GIS_Points_DisplayName")]
        //[clsParsGISDescription("GIS_Points_Description")]
        
        public List<clsGISPoint> Points
        {
            get
            {
                return this.m_Points;
            }
        }

        //[Browsable(false)]
        public clsGISPoint FromPoint
        {
            get
            {
                if (this.m_Points.Count < 2)
                    return null;
                return this.m_Points[0];
            }
            set
            {
                if (value != null)
                {
                    this.m_Points[0].X = value.X;
                    this.m_Points[0].Y = value.Y;
                    this.m_Points[0].Z = value.Z;
                    this.CalculateLength();
                }
            }
        }
        //[Browsable(false)]
        public clsGISPoint EndPoint
        {
            get
            {
                if (this.m_Points.Count < 2)
                    return null;
                return this.m_Points[this.m_Points.Count - 1];
            }
            set
            {
                if (value != null && this.m_Points.Count >= 2)
                {
                    this.m_Points[this.m_Points.Count - 1].X = value.X;
                    this.m_Points[this.m_Points.Count - 1].Y = value.Y;
                    this.m_Points[this.m_Points.Count - 1].Z = value.Z;
                    this.CalculateLength();
                }
            }
        }
        //[Browsable(false)]
        public int PointCount
        {
            get
            {
                return this.m_Points.Count;
            }
        }
        //[Browsable(false)]
        public override enmGISObjectType GISObjectType
        {
            get
            {
                return enmGISObjectType.GISObjectType_LineString;
            }
        }
        public override double MinY
        {
            get
            {
                double minY = double.MaxValue;
                foreach (clsGISPoint p in this.m_Points)
                    if (p.Y < minY)
                        minY = p.Y;
                return minY;
            }
        }
        //[Browsable(false)]
        public override double MinX
        {
            get
            {
                double minX = double.MaxValue;
                foreach (clsGISPoint p in this.m_Points)
                    if (p.X < minX)
                        minX = p.X;
                return minX;
            }
        }
        //[Browsable(false)]
        public override double MaxX
        {
            get
            {
                double maxX = double.MinValue;
                foreach (clsGISPoint p in this.m_Points)
                    if (p.X > maxX)
                        maxX = p.X;
                return maxX;
            }
        }
        //[Browsable(false)]
        public override double MaxY
        {
            get
            {
                double maxY = double.MinValue;
                foreach (clsGISPoint p in this.m_Points)
                    if (p.Y > maxY)
                        maxY = p.Y;
                return maxY;
            }
        }
        //[Browsable(false)]
        public double deltaX
        {
            get
            {
                return this.MaxX - this.MinX;
            }
        }
        //[Browsable(false)]
        public double deltaY
        {
            get
            {
                return this.MaxY - this.MinY;
            }
        }
        #endregion

        public clsGISLine GCS2UTM()
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            foreach (clsGISPoint p in this.m_Points)
            {
                clsGISPoint np = p.GCS2UTM();
                points.Add(np);
            }
            return new clsGISLine(points);
        }

        public clsGISLine UTM2GCS(Int16 zone)
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            foreach (clsGISPoint p in this.m_Points)
            {
                clsGISPoint np = p.UTM2GCS(zone);
                points.Add(np);
            }
            return new clsGISLine(points);
        }

        public clsGISLine GCS2Lambert(double centralMeridian, double parallel1, double parallel2, double originLatitude)
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            foreach (clsGISPoint p in this.m_Points)
            {
                clsGISPoint np = p.GCS2Lambert(centralMeridian, parallel1, parallel2, originLatitude);
                points.Add(np);
            }
            return new clsGISLine(points);
        }

        public clsGISLine Lambert2GCS(double centralMeridian, double parallel1, double parallel2, double originLatitude, double falseEasting, double falseNorthing)
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            foreach (clsGISPoint p in this.m_Points)
            {
                clsGISPoint np = p.Lambert2GCS(centralMeridian, parallel1, parallel2, originLatitude, falseEasting, falseNorthing);
                points.Add(np);
            }
            return new clsGISLine(points);
        }
    }

    public class clsGISRing : clsBaseGISShape
    {
        #region Private Properties
        protected List<clsGISPoint> m_Points;
        #endregion

        #region Constructors
        public clsGISRing(List<clsGISPoint> points)
        {
            this.m_Points = points;
        }

        public clsGISRing(double[] Xs, double[] Ys)
        {
            if (Xs.Length != Ys.Length || Xs.Length == 0 || Ys.Length == 0)
                return;
            this.m_Points = new List<clsGISPoint>();
            for (int i = 0; i < Xs.Length; i++)
            {
                clsGISPoint p = new clsGISPoint(Xs[i], Ys[i]);
                this.m_Points.Add(p);
            }
        }
        public clsGISRing(string wellKnownText)
        {
            string str = wellKnownText.ToUpper();
            str = str.Replace("POLYGON", "").Trim();
            str = str.Replace("),", ");").Trim();
            string[] strRings = str.Split(';');
            for (int i = 0; i < strRings.Length; i++)
            {
                clsGISLine l = new clsGISLine(strRings[i]);
                l.Points.RemoveAt(l.PointCount - 1);
                this.m_Points = l.Points;
            }
        }
        #endregion

        #region Methods
        public override bool IsNull
        {
            get
            {
                bool bAllNull = true;
                foreach (clsGISPoint p in this.m_Points)
                    bAllNull &= p.IsNull;
                return bAllNull;
            }
        }
        public static clsGISRing NullRing()
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            points.Add(clsGISPoint.NullPoint());
            points.Add(clsGISPoint.NullPoint());
            points.Add(clsGISPoint.NullPoint());
            return new clsGISRing(points);
        }
        public clsGISRing Clone()
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            for (int i = 0; i < this.m_Points.Count; i++)
                points.Add(this.m_Points[i].Clone());
            clsGISRing r = new clsGISRing(points);
            return r;
        }
        public override string ToString()
        {
            if (this.m_Points == null)
                return null;
            string str = "(";
            for (int i = 0; i < this.m_Points.Count; i++)
            {
                if (str.Length > 11)
                    str += ",";
                str += this.m_Points[i].ToString().Replace("POINT", "").Replace("(", "").Replace(")", "");
            }
            str += "," + this.m_Points[0].ToString().Replace("POINT", "").Replace("(", "").Replace(")", "");
            str += ")";
            return str;
        }
        public override int GetHashCode()
        {
            int hc = 0;
            if (this.m_Points != null)
            {
                foreach (clsGISPoint p in this.m_Points)
                    hc += p.GetHashCode();
            }
            return hc;
        }
        public override bool Equals(object obj)
        {
            if (!(obj is clsGISRing))
                return false;
            clsGISRing otherRing = obj as clsGISRing;
            if (otherRing.m_Points == null || this.m_Points == null)
                return false;
            if (otherRing.m_Points.Count != this.m_Points.Count)
                return false;
            for (int i = 0; i < this.m_Points.Count; i++)
                if (!this.m_Points[i].Equals(otherRing.m_Points[i]))
                    return false;
            return true;
        }
        public override void Transform(double baseX, double baseY, double baseZ)
        {
            foreach (clsGISPoint p in this.m_Points)
                p.Transform(baseX, baseY, baseZ);
        }
        public override void Move(double deltaX, double deltaY, double deltaZ)
        {
            foreach (clsGISPoint p in this.m_Points)
                p.Move(deltaX, deltaY, deltaZ);
        }
        public override bool ValidateGeometry()
        {
            if (this.MinEdgeLength <= (1.0 / 2260.0) || this.EdgeCount < 3)
                return false;
            return base.ValidateGeometry();
        }
        public override void MakeValid()
        {
            string str = "POLYGON(" + this.ToString() + ")";
            System.Data.SqlTypes.SqlChars wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(str));
            SqlGeometry qGeometry = SqlGeometry.STGeomFromText(wkt, 1);
            SqlGeometry validG = qGeometry.MakeValid();
            string strWKT = new string(validG.STAsText().Value);
            clsGISRing r = new clsGISRing(strWKT);
            this.m_Points = r.Points;
        }
        #endregion

        #region Public Properties
        public List<clsGISPoint> Points
        {
            get
            {
                return this.m_Points;
            }
        }
        //[Browsable(false)]
        public override enmGISObjectType GISObjectType
        {
            get
            {
                return enmGISObjectType.GISObjectType_Ring;
            }
        }
        public override double MinY
        {
            get
            {
                double minY = double.MaxValue;
                foreach (clsGISPoint p in this.m_Points)
                    if (p.Y < minY)
                        minY = p.Y;
                return minY;
            }
        }
        //[Browsable(false)]
        public override double MinX
        {
            get
            {
                double minX = double.MaxValue;
                foreach (clsGISPoint p in this.m_Points)
                    if (p.X < minX)
                        minX = p.X;
                return minX;
            }
        }
        //[Browsable(false)]
        public override double MaxX
        {
            get
            {
                double maxX = double.MinValue;
                foreach (clsGISPoint p in this.m_Points)
                    if (p.X > maxX)
                        maxX = p.X;
                return maxX;
            }
        }
        //[Browsable(false)]
        public override double MaxY
        {
            get
            {
                double maxY = double.MinValue;
                foreach (clsGISPoint p in this.m_Points)
                    if (p.Y > maxY)
                        maxY = p.Y;
                return maxY;
            }
        }
        //[Browsable(false)]
        public double MinEdgeLength
        {
            get
            {
                double val = double.MaxValue;
                for (int i = 0; i < this.m_Points.Count; i++)
                {
                    clsGISPoint p1 = this.m_Points[i];
                    int j = i + 1;
                    if (j >= this.m_Points.Count)
                        j = 0;
                    clsGISPoint p2 = this.m_Points[j];
                    double distance = p1.GetDistance(p2);
                    if (distance < val)
                        val = distance;
                }
                return val;
            }
        }
        //[Browsable(false)]
        public double MaxEdgeLength
        {
            get
            {
                double val = double.MinValue;
                for (int i = 0; i < this.m_Points.Count; i++)
                {
                    clsGISPoint p1 = this.m_Points[i];
                    int j = i + 1;
                    if (j >= this.m_Points.Count)
                        j = 0;
                    clsGISPoint p2 = this.m_Points[j];
                    double distance = p1.GetDistance(p2);
                    if (distance > val)
                        val = distance;
                }
                return val;
            }
        }
        //[Browsable(false)]
        public int EdgeCount
        {
            get
            {
                return this.m_Points.Count;
            }
        }
        //[clsParsGISCategory("Category_GIS")]
        //[clsParsGISDisplayName("GIS_Area_DisplayName")]
        //[clsParsGISDescription("GIS_Area_Description")]
        
        public double Area
        {
            get
            {
                string str = "POLYGON(" + this.ToString() + ")";

                System.Data.SqlTypes.SqlChars wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(str));
                SqlGeometry qGeometry = SqlGeometry.STGeomFromText(wkt, 1);
                return qGeometry.STArea().Value;
            }
        }
        #endregion

        public clsGISRing GCS2UTM()
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            foreach (clsGISPoint p in this.m_Points)
            {
                clsGISPoint np = p.GCS2UTM();
                points.Add(np);
            }
            return new clsGISRing(points);
        }

        public clsGISRing UTM2GCS(Int16 zone)
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            foreach (clsGISPoint p in this.m_Points)
            {
                clsGISPoint np = p.UTM2GCS(zone);
                points.Add(np);
            }
            return new clsGISRing(points);
        }

        public clsGISRing GCS2Lambert(double centralMeridian, double parallel1, double parallel2, double originLatitude)
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            foreach (clsGISPoint p in this.m_Points)
            {
                clsGISPoint np = p.GCS2Lambert(centralMeridian, parallel1, parallel2, originLatitude);
                points.Add(np);
            }
            return new clsGISRing(points);
        }

        public clsGISRing Lambert2GCS(double centralMeridian, double parallel1, double parallel2, double originLatitude, double falseEasting, double falseNorthing)
        {
            List<clsGISPoint> points = new List<clsGISPoint>();
            foreach (clsGISPoint p in this.m_Points)
            {
                clsGISPoint np = p.Lambert2GCS(centralMeridian, parallel1, parallel2, originLatitude, falseEasting, falseNorthing);
                points.Add(np);
            }
            return new clsGISRing(points);
        }
    }

    public class clsGISPolygon : clsBaseGISShape
    {
        #region Private Properties
        protected List<clsGISRing> m_Rings;
        #endregion

        #region Constructors
        public clsGISPolygon(clsGISRing ring)
        {
            this.m_Rings = new List<clsGISRing>();
            this.m_Rings.Add(ring);
        }
        public clsGISPolygon(clsGISRectangle rect)
        {
            this.m_Rings = new List<clsGISRing>();
            this.m_Rings.Add(rect);
        }
        public clsGISPolygon(List<clsGISRing> rings)
        {
            this.m_Rings = rings;
        }
        public clsGISPolygon(List<clsGISPoint> points)
        {
            clsGISRing ring = new clsGISRing(points);
            this.m_Rings = new List<clsGISRing>();
            this.m_Rings.Add(ring);
        }
        public clsGISPolygon(double[] Xs, double[] Ys)
        {
            if (Xs.Length != Ys.Length || Xs.Length == 0 || Ys.Length == 0)
                return;
            List<clsGISPoint> points = new List<clsGISPoint>();
            for (int i = 0; i < Xs.Length; i++)
            {
                clsGISPoint p = new clsGISPoint(Xs[i], Ys[i]);
                points.Add(p);
            }
            clsGISRing ring = new clsGISRing(points);
            this.m_Rings = new List<clsGISRing>();
            this.m_Rings.Add(ring);
        }
        public clsGISPolygon(string wellKnownText)
        {
            string str = wellKnownText.ToUpper();
            str = str.Replace("POLYGON", "").Trim();
            str = str.Replace("),", ");").Trim();
            string[] strRings = str.Split(';');
            for (int i = 0; i < strRings.Length; i++)
            {
                clsGISLine l = new clsGISLine(strRings[i]);
                l.Points.RemoveAt(l.PointCount - 1);
                clsGISRing r = new clsGISRing(l.Points);
                if (this.m_Rings == null)
                    this.m_Rings = new List<clsGISRing>();
                this.m_Rings.Add(r);
            }
        }
        #endregion

        #region Methods
        public override bool IsNull
        {
            get
            {
                bool bAllNull = true;
                foreach (clsGISRing r in this.m_Rings)
                    bAllNull &= r.IsNull;
                return bAllNull;
            }
        }
        public static clsGISPolygon NullPolygon()
        {
            return new clsGISPolygon(clsGISRing.NullRing());
        }
        public clsGISPolygon Clone()
        {
            List<clsGISRing> rings = new List<clsGISRing>();
            for (int i = 0; i < this.m_Rings.Count; i++)
                rings.Add(this.m_Rings[i].Clone());
            clsGISPolygon g = new clsGISPolygon(rings);
            return g;
        }
        public override string ToString()
        {
            if (this.m_Rings == null)
                return null;
            string str = "POLYGON(";
            for (int i = 0; i < this.m_Rings.Count; i++)
            {
                if (i > 0)
                    str += ",";
                str += this.m_Rings[i].ToString();
            }
            str += ")";
            return str;
        }
        public override void Transform(double baseX, double baseY, double baseZ)
        {
            foreach (clsGISRing r in this.m_Rings)
                r.Transform(baseX, baseY, baseZ);
        }
        public bool ValidateRectangle(double delta, double minWidth, double maxWidth, double minLength, double maxLength)
        {
            if (this.m_Rings.Count != 1)
                return false;
            clsGISRing r = this.m_Rings[0];
            if (r.Points.Count != 4)
                return false;
            clsGISPoint p1 = r.Points[0];
            clsGISPoint p2 = r.Points[1];
            clsGISPoint p3 = r.Points[2];
            clsGISPoint p4 = r.Points[3];

            double l1 = p1.GetDistance(p2);
            double l2 = p2.GetDistance(p3);
            double l3 = p3.GetDistance(p4);
            double l4 = p4.GetDistance(p1);

            double minw = Math.Min(l1, l3);
            double maxw = Math.Max(l1, l3);
            double minl = Math.Min(l2, l4);
            double maxl = Math.Max(l2, l4);

            return (Math.Min(minw, minl) >= Math.Min(minLength, minWidth) && Math.Max(maxl, maxw) <= Math.Max(maxLength, maxWidth));
        }
        public override bool ValidateGeometry()
        {
            bool bValid = true;
            foreach (clsGISRing r in this.m_Rings)
                bValid &= r.ValidateGeometry();
            return bValid && base.ValidateGeometry();
        }
        public override void MakeValid()
        {
            System.Data.SqlTypes.SqlChars wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(this.ToString()));
            SqlGeometry qGeometry = SqlGeometry.STGeomFromText(wkt, 1);
            SqlGeometry validG = qGeometry.MakeValid();
            string strWKT = new string(validG.STAsText().Value);
            clsGISPolygon p = new clsGISPolygon(strWKT);
            this.m_Rings = p.Rings;
        }
        public override void Move(double deltaX, double deltaY, double deltaZ)
        {
            foreach (clsGISRing r in this.Rings)
                r.Move(deltaX, deltaY, deltaZ);
        }
        #endregion

        #region Public Properties
        //[clsParsGISCategory("Category_GIS")]
        //[clsParsGISDisplayName("GIS_Rings_DisplayName")]
        //[clsParsGISDescription("GIS_Rings_Description")]
        
        public List<clsGISRing> Rings
        {
            get
            {
                return this.m_Rings;
            }
        }
        //[Browsable(false)]
        public override enmGISObjectType GISObjectType
        {
            get
            {
                return enmGISObjectType.GISObjectType_Polygon;
            }
        }
        //[Browsable(false)]
        public override double MinY
        {
            get
            {
                double minY = double.MaxValue;
                foreach (clsGISRing r in this.m_Rings)
                {
                    if (r.MinY < minY)
                        minY = r.MinY;
                }
                return minY;
            }
        }
        //[Browsable(false)]
        public override double MinX
        {
            get
            {
                double minX = double.MaxValue;
                foreach (clsGISRing r in this.m_Rings)
                {
                    if (r.MinX < minX)
                        minX = r.MinX;
                }
                return minX;
            }
        }
        //[Browsable(false)]
        public override double MaxX
        {
            get
            {
                double maxX = double.MinValue;
                foreach (clsGISRing r in this.m_Rings)
                {
                    if (r.MaxX > maxX)
                        maxX = r.MaxX;
                }
                return maxX;
            }
        }
        //[Browsable(false)]
        public override double MaxY
        {
            get
            {
                double maxY = double.MinValue;
                foreach (clsGISRing r in this.m_Rings)
                {
                    if (r.MaxY > maxY)
                        maxY = r.MaxY;
                }
                return maxY;
            }
        }
        //[Browsable(false)]
        public double MinEdgeLength
        {
            get
            {
                double val = double.MaxValue;
                for (int i = 0; i < this.m_Rings.Count; i++)
                {
                    clsGISRing r = this.m_Rings[i];
                    if (r.MinEdgeLength < val)
                        val = r.MinEdgeLength;
                }
                return val;
            }
        }
        //[Browsable(false)]
        public double MaxEdgeLength
        {
            get
            {
                double val = double.MinValue;
                for (int i = 0; i < this.m_Rings.Count; i++)
                {
                    clsGISRing r = this.m_Rings[i];
                    if (r.MinEdgeLength > val)
                        val = r.MaxEdgeLength;
                }
                return val;
            }
        }
        //[Browsable(false)]
        public int EdgeCount
        {
            get
            {
                int cnt = 0;
                foreach (clsGISRing r in this.m_Rings)
                    if (r.EdgeCount > cnt)
                        cnt = r.EdgeCount;
                return cnt;
            }
        }
        //[clsParsGISCategory("Category_GIS")]
        //[clsParsGISDisplayName("GIS_Area_DisplayName")]
        //[clsParsGISDescription("GIS_Area_Description")]
        
        public double Area
        {
            get
            {
                double a = 0;
                foreach (clsGISRing r in this.m_Rings)
                    a += r.Area;
                return a;
            }
        }
        #endregion

        public clsGISPolygon GCS2UTM()
        {
            List<clsGISRing> rings = new List<clsGISRing>();
            foreach (clsGISRing r in this.m_Rings)
            {
                clsGISRing nr = r.GCS2UTM();
                rings.Add(nr);
            }
            return new clsGISPolygon(rings);
        }
        public clsGISPolygon UTM2GCS(Int16 zone)
        {
            List<clsGISRing> rings = new List<clsGISRing>();
            foreach (clsGISRing r in this.m_Rings)
            {
                clsGISRing nr = r.UTM2GCS(zone);
                rings.Add(nr);
            }
            return new clsGISPolygon(rings);
        }
        public clsGISPolygon GCS2Lambert(double centralMeridian, double parallel1, double parallel2, double originLatitude)
        {
            List<clsGISRing> rings = new List<clsGISRing>();
            foreach (clsGISRing r in this.m_Rings)
            {
                clsGISRing nr = r.GCS2Lambert(centralMeridian, parallel1, parallel2, originLatitude);
                rings.Add(nr);
            }
            return new clsGISPolygon(rings);
        }
        public clsGISPolygon Lambert2GCS(double centralMeridian, double parallel1, double parallel2, double originLatitude, double falseEasting, double falseNorthing)
        {
            List<clsGISRing> rings = new List<clsGISRing>();
            foreach (clsGISRing r in this.m_Rings)
            {
                clsGISRing nr = r.Lambert2GCS(centralMeridian, parallel1, parallel2, originLatitude, falseEasting, falseNorthing);
                rings.Add(nr);
            }
            return new clsGISPolygon(rings);
        }
    }

    public class clsGISRectangle : clsGISRing
    {
        #region Constructors
        public clsGISRectangle(List<clsGISPoint> points)
            : base(points)
        {
        }

        public clsGISRectangle(clsGISPoint topLeft, double width, double height, enmXYCoordinationRegion region)
            : base(new List<clsGISPoint>())
        {
            this.m_Points.Add(topLeft);
            switch (region)
            {
                case enmXYCoordinationRegion.XYCoordinationRegion_1:
                    {
                        this.m_Points.Add(new clsGISPoint(topLeft.X + width, topLeft.Y));
                        this.m_Points.Add(new clsGISPoint(topLeft.X + width, topLeft.Y + height));
                        this.m_Points.Add(new clsGISPoint(topLeft.X, topLeft.Y + height));
                    }
                    break;
                case enmXYCoordinationRegion.XYCoordinationRegion_2:
                    {
                        this.m_Points.Add(new clsGISPoint(topLeft.X - width, topLeft.Y));
                        this.m_Points.Add(new clsGISPoint(topLeft.X - width, topLeft.Y + height));
                        this.m_Points.Add(new clsGISPoint(topLeft.X, topLeft.Y + height));
                    }
                    break;
                case enmXYCoordinationRegion.XYCoordinationRegion_3:
                    {
                        this.m_Points.Add(new clsGISPoint(topLeft.X - width, topLeft.Y));
                        this.m_Points.Add(new clsGISPoint(topLeft.X - width, topLeft.Y - height));
                        this.m_Points.Add(new clsGISPoint(topLeft.X, topLeft.Y - height));
                    }
                    break;
                case enmXYCoordinationRegion.XYCoordinationRegion_4:
                    {
                        this.m_Points.Add(new clsGISPoint(topLeft.X + width, topLeft.Y));
                        this.m_Points.Add(new clsGISPoint(topLeft.X + width, topLeft.Y - height));
                        this.m_Points.Add(new clsGISPoint(topLeft.X, topLeft.Y - height));
                    }
                    break;
            }
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return base.ToString();
        }
        public override bool ValidateGeometry()
        {
            bool b = base.ValidateGeometry();
            b &= this.m_Points.Count == 4;
            return b;
        }
        #endregion

        #region Public Properties
        public double Width
        {
            get
            {
                if (this.m_Points.Count != 4)
                    return 0.0;
                clsGISPoint topLeft = this.m_Points[0];
                clsGISPoint topRight = this.m_Points[1];
                return Math.Abs(topLeft.GetDistance(topRight));
            }
        }

        public double Height
        {
            get
            {
                if (this.m_Points.Count != 4)
                    return 0.0;
                clsGISPoint topLeft = this.m_Points[0];
                clsGISPoint bottomLeft = this.m_Points[3];
                return Math.Abs(topLeft.GetDistance(bottomLeft));
            }
        }
        #endregion
    }

    public class clsGISMultiLine : clsBaseGISShape
    {
        private List<clsGISLine> m_Lines = new List<clsGISLine>();

        #region Constractors
        public clsGISMultiLine(clsGISLine line)
        {
            this.m_Lines.Add(line);
        }

        public clsGISMultiLine(List<clsGISLine> lines)
        {
            this.m_Lines.AddRange(lines);
        }

        public clsGISMultiLine(string wkt)
        {
            string str = wkt.ToUpper().Replace("MULTILINESTRING", "");
            str = str.Replace("((", "(").Replace("))", ")");
            str = str.Replace("),", ");").Trim();
            string[] strLines = str.Split(';');
            foreach (string s in strLines)
            {
                clsGISLine l = new clsGISLine(s);
                if (l != null)
                    this.m_Lines.Add(l);
            }
        }
        #endregion

        #region Methods
        public static clsGISMultiLine NullMultiLine()
        {
            return new clsGISMultiLine(clsGISLine.NullLine());
        }
        public override string ToString()
        {
            string str = "";
            foreach (clsGISLine l in this.m_Lines)
                str = l.ToString().ToUpper().Replace("LINESTRING", "");
            if (str.Length > 0)
                str = "MULTILINESTRING(" + str + ")";
            return str;
        }
        public override double MaxX
        {
            get
            {
                double x = double.MinValue;
                foreach (clsGISLine l in this.m_Lines)
                    if (x < l.MaxX)
                        x = l.MaxX;
                return x;
            }
        }
        public override double MaxY
        {
            get
            {
                double x = double.MinValue;
                foreach (clsGISLine l in this.m_Lines)
                    if (x < l.MaxY)
                        x = l.MaxY;
                return x;
            }
        }
        public override double MinX
        {
            get
            {
                double x = double.MaxValue;
                foreach (clsGISLine l in this.m_Lines)
                    if (x > l.MinX)
                        x = l.MinX;
                return x;
            }
        }
        public override double MinY
        {
            get
            {
                double x = double.MaxValue;
                foreach (clsGISLine l in this.m_Lines)
                    if (x > l.MinY)
                        x = l.MinY;
                return x;
            }
        }
        public override bool IsNull
        {
            get
            {
                bool bAll = true;
                foreach (clsGISLine l in this.m_Lines)
                    bAll &= l.IsNull;
                return bAll;
            }
        }
        public override int GetHashCode()
        {
            int hc = 0;
            foreach (clsGISLine l in this.m_Lines)
                hc += l.GetHashCode();
            return hc;
        }
        public override bool Equals(object obj)
        {
            if (!(obj is clsGISMultiLine))
                return false;
            clsGISMultiLine other = obj as clsGISMultiLine;
            if (other.GISLines.Count != this.m_Lines.Count)
                return false;
            for (int i = 0; i < other.GISLines.Count; i++)
            {
                clsGISLine l1 = this.GISLines[i];
                clsGISLine l2 = other.GISLines[i];
                if (!l1.Equals(l2))
                    return false;
            }
            return true;
        }
        public override void MakeValid()
        {
            System.Data.SqlTypes.SqlChars wkt = new System.Data.SqlTypes.SqlChars(new System.Data.SqlTypes.SqlString(this.ToString()));
            SqlGeometry qGeometry = SqlGeometry.STGeomFromText(wkt, 1);
            SqlGeometry validG = qGeometry.MakeValid();
            string strWKT = new string(validG.STAsText().Value);
            clsGISMultiLine m = new clsGISMultiLine(strWKT);
            this.m_Lines = m.m_Lines;
        }
        public override void Move(double deltaX, double deltaY, double deltaZ)
        {
            foreach (clsGISLine l in this.m_Lines)
                l.Move(deltaX, deltaY, deltaZ);
        }
        public override void Transform(double baseX, double baseY, double baseZ)
        {
            foreach (clsGISLine l in this.m_Lines)
                l.Transform(baseX, baseY, baseZ);
        }
        public override bool ValidateGeometry()
        {
            bool bAll = true;
            foreach (clsGISLine l in this.m_Lines)
                bAll &= l.ValidateGeometry();
            return bAll;
        }
        #endregion

        #region Properties
        public double MultiLineLength
        {
            get
            {
                double d = 0;
                foreach (clsGISLine l in this.GISLines)
                    d += l.LineLength;
                return d;
            }
        }
        public override enmGISObjectType GISObjectType
        {
            get
            {
                return enmGISObjectType.GISObjectType_MultiLineString;
            }
        }
        public List<clsGISLine> GISLines
        {
            get
            {
                return this.m_Lines;
            }
        }
        #endregion

        public clsGISMultiLine GCS2UTM()
        {
            List<clsGISLine> lines = new List<clsGISLine>();
            foreach (clsGISLine r in this.m_Lines)
            {
                clsGISLine nr = r.GCS2UTM();
                lines.Add(nr);
            }
            return new clsGISMultiLine(lines);
        }
        public clsGISMultiLine UTM2GCS(Int16 zone)
        {
            List<clsGISLine> rings = new List<clsGISLine>();
            foreach (clsGISLine r in this.m_Lines)
            {
                clsGISLine nr = r.UTM2GCS(zone);
                rings.Add(nr);
            }
            return new clsGISMultiLine(rings);
        }
        public clsGISMultiLine GCS2Lambert(double centralMeridian, double parallel1, double parallel2, double originLatitude)
        {
            List<clsGISLine> rings = new List<clsGISLine>();
            foreach (clsGISLine r in this.m_Lines)
            {
                clsGISLine nr = r.GCS2Lambert(centralMeridian, parallel1, parallel2, originLatitude);
                rings.Add(nr);
            }
            return new clsGISMultiLine(rings);
        }
        public clsGISMultiLine Lambert2GCS(double centralMeridian, double parallel1, double parallel2, double originLatitude, double falseEasting, double falseNorthing)
        {
            List<clsGISLine> rings = new List<clsGISLine>();
            foreach (clsGISLine r in this.m_Lines)
            {
                clsGISLine nr = r.Lambert2GCS(centralMeridian, parallel1, parallel2, originLatitude, falseEasting, falseNorthing);
                rings.Add(nr);
            }
            return new clsGISMultiLine(rings);
        }
    }
}
