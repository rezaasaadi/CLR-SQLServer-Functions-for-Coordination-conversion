//------------------------------------------------------------------------------
// <copyright file="CSSqlFunction.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlString FNGetWKT_GCS2Lambert(SqlString wkt, SqlDouble centralMeridian, SqlDouble parallel1, SqlDouble parallel2, SqlDouble originLatitude)
    {
        string strResult = string.Empty;
        string strWKT = wkt.ToString();
        double cenM = centralMeridian.Value;
        double par1 = parallel1.Value;
        double par2 = parallel2.Value;
        double orL = originLatitude.Value;
        if (strWKT.ToLower().IndexOf("point") >= 0 && strWKT.ToLower().IndexOf("multipoint") < 0)
        {
            CoordConversion.clsGISPoint point = new CoordConversion.clsGISPoint(strWKT);
            point = point.GCS2Lambert(cenM, par1, par2, orL);
            strResult = point.ToString();
        }
        if (strWKT.ToLower().IndexOf("linestring") >= 0 && strWKT.ToLower().IndexOf("multilinestring") < 0)
        {
            CoordConversion.clsGISLine line = new CoordConversion.clsGISLine(strWKT);
            line = line.GCS2Lambert(cenM, par1, par2, orL);
            strResult = line.ToString();
        }
        if (strWKT.ToLower().IndexOf("polygon") >= 0)
        {
            CoordConversion.clsGISPolygon polygon = new CoordConversion.clsGISPolygon(strWKT);
            polygon = polygon.GCS2Lambert(cenM, par1, par2, orL);
            strResult = polygon.ToString();
        }
        if (strWKT.ToLower().IndexOf("multilinestring") >= 0)
        {
            CoordConversion.clsGISMultiLine ml = new CoordConversion.clsGISMultiLine(strWKT);
            ml = ml.GCS2Lambert(cenM, par1, par2, orL);
            strResult = ml.ToString();
        }
        return new SqlString(strResult);
    }
}
